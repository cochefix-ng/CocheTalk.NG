# CocheTalk.NG — Global Aftersales & Auto Marketplace

Comprehensive, high-performance Android application built with Jetpack Compose, targeting Android 14+ (SDK 36) and engineered for the **Nigerian Aftersales Auto-Ecosystem**. This app combines an interactive **Q&A Forum**, a dynamic **Service Provider Directory**, and an **Auto Marketplace** supporting precise part grade and brand definitions.

---

## 📱 Application Overview

CocheTalk.NG is a full-featured vehicle maintenance, parts sourcing, and service provider discovery platform. Key capabilities include:

*   **Frictionless Simulation Profiles**: Instantly switch roles or identities among default seeded personas (e.g., *Bisi Alao*, *Samson Okeke*, *Jose Silverio*) to experience user-specific features.
*   **Auto Parts & Services Marketplace**: Dedicated workflows for listing/sourcing vehicle products. When listing a core **Part**, vendors specify its **Part Brand** (e.g., Toyota OEM, Bosch, Denso) and **Parts Grade** (e.g., OEM, aftermarket, refurb), alongside its fitment application.
*   **Technician Diagnostic Forum & CocheFix AI**: Q&A discussion board powered by real-time Gemini AI mechanical diagnostics. 
*   **Service Provider Directory**: Real-time hiring, reviews, and interactive communication links (direct call and WhatsApp links).
*   **Database Management Tools**: Powerful factory resets, database backup exports (master JSON/CSV formats), and diagnostics tools built directly into the UI for developers.

---

## 🛠️ Production Tech Stack

*   **UI Framework**: Jetpack Compose styled strictly under **Material 3 (M3)** with custom component-level elevations, dynamic rounded shapes, fluid transitions, and a clean slate-silver twilight theme.
*   **Architecture**: Model-View-ViewModel (MVVM) coupled with clean Repository abstraction and Kotlin Coroutines/StateFlow for state management.
*   **Local DB Persistence**: **Room Database** (Room v2.6+) containing fully typed relational tables with automated destructive/fallback migrations during development cycles.
*   **Network Service**: **Retrofit 2** & **Moshi** for robust, highly efficient API interactions (used extensively by the Gemini AI gateway client).
*   **Security & Environment Configuration**: Configured via the **Secrets Gradle Plugin** allowing environment-variable configurations using `.env` parameters without hardcoding keys.

---

## 📁 Key Codebase Directory Structure

```text
/app/src/main/
├── AndroidManifest.xml                         # Native application declarations, activities, and deep-link handles
├── java/com/example/
│   ├── MainActivity.kt                         # Application entry point & screen initialization
│   ├── data/
│   │   ├── local/
│   │   │   ├── AppDao.kt                       # SQL Transaction definitions (Users, Listings, Forum Q&As, Ratings)
│   │   │   └── AppDatabase.kt                  # Room Setup, schema definitions, and automated database seeding routines
│   │   ├── model/
│   │   │   └── Models.kt                       # Local serialization models (User, MarketplaceListing, Question, Rating, AdminAnalytics)
│   │   └── api/
│   │       └── GeminiClient.kt                 # Retrofit interface and Prompt Engineer templates for Gemini 1.5/3.5 Flash
│   └── ui/
│       ├── MainViewModel.kt                    # Global business logic, cache state flows, & analytical exports
│       ├── theme/
│       │   ├── Color.kt                        # Palette representing high-contrast automotive color scheme
│       │   ├── Theme.kt                        # Material 3 setup supporting standard light/dark adaptive dynamics
│       │   └── Type.kt                         # Typography hierarchy for optimal UI scanning
│       └── screens/
│           └── CocheFixApp.kt                  # Single-activity composable views, interactive dialogues, diagnostics layouts, exports
```

---

## 🔐 Configuring Gemini AI API Gateway

The AI mechanic diagnostics service uses **Gemini 1.5/3.5 Flash**. In live production, these keys are securely managed.

### 1. Local Development Setup
Create a file named `.env` at the project's root folder:
```env
GEMINI_API_KEY=YOUR_ACTUAL_API_KEY_HERE
```
The Secrets Gradle Plugin dynamically parses this file and compiles the key into the generated `BuildConfig` class (`com.example.BuildConfig.GEMINI_API_KEY`).

### 2. CI/CD & GitHub Actions Production Workflow
Define a secret variable within your CI/CD repository settings named `GEMINI_API_KEY`. The secrets compiler automatically generates the local properties when building an APK.

---

## 🚀 Production Handover Checklist

When migrating this codebase from staging/simulation to active live production, complete these core steps:

### 1. Update Application ID & Namespace
In `app/build.gradle.kts`, change the `applicationId` to match your production domain:
```kotlin
android {
    defaultConfig {
        applicationId = "com.cochetalk.app" // Your live bundle identifier
    }
}
```

### 2. Configure Final Keystore Signing
Replace the debug signing files with your verified upload certificates in Google Play Console. Provide the build passwords to your secure environment runners.

### 3. Verify Database Migration Strategies
If the database schema changes post-release, define concrete increment migrations in `AppDatabase.kt` instead of `.fallbackToDestructiveMigration()` to prevent user data loss:
```kotlin
// Example migration implementation:
val MIGRATION_8_9 = object : Migration(8, 9) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE marketplace_listings ADD COLUMN warranty_months INTEGER DEFAULT 0 NOT NULL")
    }
}
```

### 4. Optimize the Proguard / R8 Shrinker
Before compilation, verify configuration rules in `proguard-rules.pro` to keep your Room-entities and Moshi Reflection adapters obfuscated but unharmed during release compaction.

---

## ⚙️ How to Seeding / Factory Reset DB
If you modify static databases or mock scenarios, utilize the administrative **Factory Reset** and diagnostic tools on the **Admin Screen** inside the app. This calls:
`MainViewModel.resetDatabaseToDefaults(context)` to drop local schemas and re-seed the standard ecosystem profile configurations automatically!

---
*Created with care by the Google AI Studio Coding Assistant.*
