package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini API Request / Response Models using Moshi ---

@JsonClass(generateAdapter = true)
data class Part(
    @field:Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class Content(
    @field:Json(name = "parts") val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    @field:Json(name = "contents") val contents: List<Content>
)

@JsonClass(generateAdapter = true)
data class Candidate(
    @field:Json(name = "content") val content: Content?
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    @field:Json(name = "candidates") val candidates: List<Candidate>?
)

// --- Retrofit Interface ---

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

// --- Retrofit Client ---

object GeminiRetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()

    val service: GeminiApiService = retrofit.create(GeminiApiService::class.java)
}

// --- Diagnostic Helper ---

object GeminiHelper {
    suspend fun diagnoseVehicleIssue(description: String): String {
        val apiKey = com.example.BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return """
                ⚠️ CocheFix AI Assistant key configuration required!
                
                To enable deep AI diagnostic predictions, enter your GEMINI_API_KEY in the Secrets panel of Google AI Studio. 
                
                Based on offline lookups, for critical issues such as "$description":
                - Immediately pull over if there is red smoke, engine knocking, or brake failures.
                - Find and contact a local verified Service Provider on the CocheFix Forums or Marketplace immediately.
            """.trimIndent()
        }

        val prompt = """
            You are CocheFix AI, an expert vehicle diagnostics assistant.
            A user of our platform described the following issue with their vehicle:
            "$description"
            
            Provide a complete mechanical analysis:
            1. Likely Causes (rank by probability, from simple fuse/fluids to complex repairs).
            2. Troubleshooting Steps (what can they check right now? Be safe, e.g., don't open hot radiators).
            3. Action Recommendation (is this a DIY fix or requires professional gear?).
            4. Encouraging Closing (suggest they post on CocheFix Forum or hire a verified workshop).
            
            Formatting rules:
            - Use clean Markdown with clear emoji-bullet headings.
            - Keep paragraphs brief and easy to read on mobile.
            - Do not include technical compile or programming jargon.
        """.trimIndent()

        val request = GenerateContentRequest(
            contents = listOf(
                Content(parts = listOf(Part(text = prompt)))
            )
        )

        return try {
            val response = GeminiRetrofitClient.service.generateContent(apiKey, request)
            response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: "CocheFix AI did not generate a response. Please re-state your vehicle issue."
        } catch (e: Exception) {
            """
                🔴 AI Diagnostics Diagnostics Error: ${e.localizedMessage ?: "Connection timed out"}
                
                Please ensure you are connected to the internet and retry. If this problem persists, you can post your question on the CocheFix Q&A forums where our community of verified expert technicians can assist you.
            """.trimIndent()
        }
    }
}
