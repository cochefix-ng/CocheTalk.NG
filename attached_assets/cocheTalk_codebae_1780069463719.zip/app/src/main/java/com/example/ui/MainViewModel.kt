package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiHelper
import com.example.data.model.*
import com.example.data.repository.AppRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainViewModel(private val repository: AppRepository) : ViewModel() {

    // --- Authentication State ---
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    val allUsers: StateFlow<List<User>> = repository.allUsers
        .catch { e -> e.printStackTrace(); emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Forum States ---
    val allQuestions: StateFlow<List<Question>> = repository.allQuestions
        .catch { e -> e.printStackTrace(); emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allAnswersGlobal: StateFlow<List<Answer>> = repository.allAnswersGlobal
        .catch { e -> e.printStackTrace(); emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Marketplace Listings ---
    val allListings: StateFlow<List<MarketplaceListing>> = repository.allListings
        .catch { e -> e.printStackTrace(); emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Provider Ratings ---
    val allRatingsGlobal: StateFlow<List<ProviderRating>> = repository.allRatingsGlobal
        .catch { e -> e.printStackTrace(); emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Comments ---
    val allCommentsGlobal: StateFlow<List<Comment>> = repository.allCommentsGlobal
        .catch { e -> e.printStackTrace(); emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- CMS Customization Configuration ---
    val cmsConfig: StateFlow<CmsConfig> = repository.cmsConfig
        .map { it ?: CmsConfig() }
        .catch { e -> e.printStackTrace(); emit(CmsConfig()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = CmsConfig()
        )

    // --- Admin Analytics State ---
    val adminAnalytics: StateFlow<AdminAnalytics> = repository.adminAnalytics
        .map { it ?: AdminAnalytics() }
        .catch { e -> e.printStackTrace(); emit(AdminAnalytics()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AdminAnalytics()
        )

    fun trackPageVisit(route: String) {
        viewModelScope.launch {
            when (route) {
                "forum" -> repository.incrementVisitsForum()
                "private_eco" -> repository.incrementVisitsProCircle()
                "marketplace" -> repository.incrementVisitsMarketplace()
                "ai_diagnostics" -> repository.incrementVisitsAiDiagnostics()
                "settings" -> repository.incrementVisitsSettings()
            }
        }
    }

    fun trackWhatsappClick() {
        viewModelScope.launch {
            repository.incrementWhatsappClicks()
        }
    }

    fun trackAiQuestion() {
        viewModelScope.launch {
            repository.incrementAiQuestionsCount()
        }
    }

    fun trackUpvote() {
        viewModelScope.launch {
            repository.incrementUpvotesGivenCount()
        }
    }

    // --- AI Diagnostic prediction state ---
    private val _aiDiagnosticLoading = MutableStateFlow(false)
    val aiDiagnosticLoading: StateFlow<Boolean> = _aiDiagnosticLoading.asStateFlow()

    private val _aiDiagnosticResult = MutableStateFlow<String?>(null)
    val aiDiagnosticResult: StateFlow<String?> = _aiDiagnosticResult.asStateFlow()

    // --- Active Forum Filters ---
    val forumSearchQuery = MutableStateFlow("")
    val activeForumFilter = MutableStateFlow("Latest") // "Latest", "Most Answered", "Unanswered"
    val activeForumTag = MutableStateFlow("")

    // Initialize with a default user for friction-free simulation
    init {
        viewModelScope.launch {
            try {
                // Pick Bisi Alao as default on initial boot, but user can sign-out or switch roles easily!
                var bisiUser = repository.getUser("bisi@cochefix.com")
                if (bisiUser == null) {
                    repository.seedDatabase()
                    bisiUser = repository.getUser("bisi@cochefix.com")
                }
                if (bisiUser != null) {
                    _currentUser.value = bisiUser
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // --- Authentication Actions ---
    fun loginAsUser(user: User) {
        viewModelScope.launch {
            val dbUser = repository.getUser(user.id)
            if (dbUser != null) {
                if (dbUser.isBanned) {
                    // Fail if banned
                    return@launch
                }
                _currentUser.value = dbUser
            } else {
                repository.insertUser(user)
                _currentUser.value = user
            }
        }
    }

    fun login(email: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val user = repository.getUser(email)
            if (user == null) {
                onResult(false, "User not found. Please register during onboarding!")
            } else if (user.isBanned) {
                onResult(false, "This account is suspended by administration.")
            } else {
                _currentUser.value = user
                onResult(true, "Successfully logged in as ${user.name}!")
            }
        }
    }

    fun register(
        email: String,
        name: String,
        role: String,
        phone: String = "",
        specialization: String = "",
        businessName: String = "",
        experience: Int = 0,
        location: String = ""
    ) {
        viewModelScope.launch {
            val newUser = User(
                id = email,
                name = name,
                email = email,
                role = role,
                verified = role == "Admin", // Admin starts verified
                phone = phone,
                specialization = specialization,
                businessName = businessName,
                experience = experience,
                location = location
            )
            repository.insertUser(newUser)
            _currentUser.value = newUser
        }
    }

    fun logout() {
        _currentUser.value = null
    }

    // --- Q&A Forum Actions ---
    fun askQuestion(
        title: String,
        description: String,
        tags: String,
        isPrivate: Boolean,
        yrModel: String = "",
        vehicleType: String = "",
        seeConcern: Boolean = false,
        hearConcern: Boolean = false,
        smellConcern: Boolean = false,
        feelConcern: Boolean = false,
        notStarting: Boolean = false,
        performanceConcern: Boolean = false,
        dashboardWarningLights: Boolean = false
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val q = Question(
                title = title,
                description = description,
                userId = user.id,
                userName = user.name,
                userRole = user.role,
                userSpecialization = if (user.role == "Service Provider") user.specialization else null,
                userVerified = user.verified,
                tags = tags,
                isPrivateEcosystem = isPrivate,
                yrModel = yrModel,
                vehicleType = vehicleType,
                seeConcern = seeConcern,
                hearConcern = hearConcern,
                smellConcern = smellConcern,
                feelConcern = feelConcern,
                notStarting = notStarting,
                performanceConcern = performanceConcern,
                dashboardWarningLights = dashboardWarningLights
            )
            repository.insertQuestion(q)
        }
    }

    fun answerQuestion(questionId: Int, content: String) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val a = Answer(
                questionId = questionId,
                userId = user.id,
                userName = user.name,
                userRole = user.role,
                userSpecialization = if (user.role == "Service Provider") user.specialization else null,
                userVerified = user.verified,
                content = content
            )
            repository.insertAnswer(a)
        }
    }

    fun addComment(parentId: Int, isAnswer: Boolean, content: String) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val c = Comment(
                questionOrAnswerId = parentId,
                isAnswer = isAnswer,
                userId = user.id,
                userName = user.name,
                content = content
            )
            repository.insertComment(c)
        }
    }

    fun upvoteQuestion(questionId: Int) {
        viewModelScope.launch {
            repository.upvoteQuestion(questionId)
            trackUpvote()
        }
    }

    fun upvoteAnswer(answerId: Int) {
        viewModelScope.launch {
            repository.upvoteAnswer(answerId)
            trackUpvote()
        }
    }

    fun acceptAnswer(questionId: Int, answerId: Int) {
        viewModelScope.launch {
            repository.acceptAnswerOnQuestion(questionId, answerId)
            repository.updateAnswerAccepted(answerId, true)
        }
    }

    fun deleteQuestion(questionId: Int) {
        viewModelScope.launch {
            repository.deleteQuestion(questionId)
        }
    }

    // --- Marketplace Actions ---
    fun listProductOrService(
        title: String,
        description: String,
        price: Double,
        category: String,
        location: String,
        partsGrade: String = "",
        application: String = "",
        partBrand: String = ""
    ) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            val listing = MarketplaceListing(
                title = title,
                description = description,
                price = price,
                userId = user.id,
                userName = user.name,
                userRole = user.role,
                userPhone = user.phone.ifEmpty { "+15550199" }, // WhatsApp default fallback if missing
                category = category,
                location = location,
                isApproved = user.role == "Admin", // Admin listings automatically approved
                partsGrade = partsGrade,
                application = application,
                partBrand = partBrand
            )
            repository.insertListing(listing)
        }
    }

    fun deleteListing(listingId: Int) {
        viewModelScope.launch {
            repository.deleteListing(listingId)
        }
    }

    // --- Admin Operations ---
    fun toggleUserVerification(userId: String, verified: Boolean) {
        viewModelScope.launch {
            repository.updateUserVerification(userId, verified)
        }
    }

    fun toggleUserBanned(userId: String, isBanned: Boolean) {
        viewModelScope.launch {
            repository.updateUserBanned(userId, isBanned)
            // If they are currently logged in user, logout
            if (isBanned && _currentUser.value?.id == userId) {
                logout()
            }
        }
    }

    fun approveMarketItem(listingId: Int, approved: Boolean) {
        viewModelScope.launch {
            repository.updateListingApproval(listingId, approved)
        }
    }

    fun toggleListingFeaturedBottom(listingId: Int, featured: Boolean) {
        viewModelScope.launch {
            repository.updateListingFeaturedBottom(listingId, featured)
        }
    }

    fun adminSaveUserProfile(user: User) {
        viewModelScope.launch {
            repository.insertUser(user)
            if (_currentUser.value?.id == user.id) {
                _currentUser.value = user
            }
        }
    }

    fun adminDeleteUser(userId: String) {
        viewModelScope.launch {
            repository.deleteUser(userId)
            if (_currentUser.value?.id == userId) {
                _currentUser.value = null
            }
        }
    }

    fun updateCmsConfig(logo: String, landing: String, banner: String, announcement: String, logoUrl: String, logoIconName: String) {
        viewModelScope.launch {
            val newCms = CmsConfig(
                logoText = logo,
                landingText = landing,
                bannerText = banner,
                announcementText = announcement,
                logoUrl = logoUrl,
                logoIconName = logoIconName
            )
            repository.insertCmsConfig(newCms)
        }
    }

    // --- Gemini Diagnostics Action ---
    fun runAiDiagnostic(description: String) {
        if (description.isBlank()) return
        _aiDiagnosticLoading.value = true
        _aiDiagnosticResult.value = null
        trackAiQuestion()
        viewModelScope.launch {
            try {
                val diagnosis = GeminiHelper.diagnoseVehicleIssue(description)
                _aiDiagnosticResult.value = diagnosis
            } finally {
                _aiDiagnosticLoading.value = false
            }
        }
    }

    fun clearAiDiagnostics() {
        _aiDiagnosticResult.value = null
    }

    // Reactive comments helper
    fun getCommentsForParent(parentId: Int, isAnswer: Boolean): Flow<List<Comment>> {
        return repository.getComments(parentId, isAnswer)
    }

    // Get single answers helper
    fun getAnswersForQuestionFlow(questionId: Int): Flow<List<Answer>> {
        return repository.getAnswersForQuestion(questionId)
    }

    // Rating function
    fun addProviderRating(providerId: String, raterId: String, raterName: String, ratingValue: Int, feedback: String) {
        viewModelScope.launch {
            repository.insertRating(
                com.example.data.model.ProviderRating(
                    providerId = providerId,
                    raterId = raterId,
                    raterName = raterName,
                    ratingValue = ratingValue,
                    feedback = feedback
                )
            )
        }
    }

    // Diagnostics / Factory Reset DB
    fun resetDatabaseToDefaults(context: android.content.Context) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val db = com.example.data.local.AppDatabase.getDatabase(context)
                    db.clearAllTables()
                    repository.seedDatabase()
                }
                val bisiUser = repository.getUser("bisi@cochefix.com")
                if (bisiUser != null) {
                    _currentUser.value = bisiUser
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}

class MainViewModelFactory(private val repository: AppRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MainViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
