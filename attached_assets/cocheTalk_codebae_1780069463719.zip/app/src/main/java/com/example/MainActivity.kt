package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.AppDatabase
import com.example.data.repository.AppRepository
import com.example.ui.MainViewModel
import com.example.ui.MainViewModelFactory
import com.example.ui.screens.CocheFixApp
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Room Database and populate seed values
    val database = AppDatabase.getDatabase(applicationContext)
    val repository = AppRepository(database.appDao())

    setContent {
      MyApplicationTheme {
        // Instantiate ViewModel using Compose viewModel tool and custom Factory
        val mainViewModel: MainViewModel = viewModel(
          factory = MainViewModelFactory(repository)
        )
        CocheFixApp(viewModel = mainViewModel)
      }
    }
  }
}
