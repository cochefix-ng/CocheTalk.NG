package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AppRepository(private val appDao: AppDao) {
    // --- User Repo Methods ---
    suspend fun getUser(id: String): User? = appDao.getUser(id)
    
    val allUsers: Flow<List<User>> = appDao.getAllUsers()
    
    suspend fun insertUser(user: User) {
        appDao.insertUser(user)
    }
    
    suspend fun updateUserVerification(id: String, verified: Boolean) {
        appDao.updateUserVerification(id, verified)
    }
    
    suspend fun updateUserBanned(id: String, isBanned: Boolean) {
        appDao.updateUserBanned(id, isBanned)
    }

    suspend fun deleteUser(id: String) {
        appDao.deleteUser(id)
    }

    // --- Question Repo Methods ---
    val allQuestions: Flow<List<Question>> = appDao.getAllQuestions()
    
    fun getQuestionById(id: Int): Flow<Question?> = appDao.getQuestionById(id)
    
    suspend fun insertQuestion(question: Question): Long {
        return appDao.insertQuestion(question)
    }
    
    suspend fun deleteQuestion(id: Int) {
        appDao.deleteQuestion(id)
    }
    
    suspend fun upvoteQuestion(id: Int) {
        appDao.upvoteQuestion(id)
    }
    
    suspend fun acceptAnswerOnQuestion(id: Int, answerId: Int) {
        appDao.acceptAnswerOnQuestion(id, answerId)
    }

    // --- Answer Repo Methods ---
    val allAnswersGlobal: Flow<List<Answer>> = appDao.getAllAnswersGlobal()

    fun getAnswersForQuestion(questionId: Int): Flow<List<Answer>> {
        return appDao.getAnswersForQuestion(questionId)
    }
    
    suspend fun insertAnswer(answer: Answer): Long {
        return appDao.insertAnswer(answer)
    }
    
    suspend fun deleteAnswer(id: Int) {
        appDao.deleteAnswer(id)
    }
    
    suspend fun upvoteAnswer(id: Int) {
        appDao.upvoteAnswer(id)
    }
    
    suspend fun updateAnswerAccepted(id: Int, isAccepted: Boolean) {
        appDao.updateAnswerAccepted(id, isAccepted)
    }

    // --- Comment Repo Methods ---
    val allCommentsGlobal: Flow<List<Comment>> = appDao.getAllCommentsGlobal()

    fun getComments(parentId: Int, isAnswer: Boolean): Flow<List<Comment>> {
        return appDao.getComments(parentId, isAnswer)
    }
    
    suspend fun insertComment(comment: Comment): Long {
        return appDao.insertComment(comment)
    }

    // --- Marketplace Repo Methods ---
    val allListings: Flow<List<MarketplaceListing>> = appDao.getAllListings()
    
    suspend fun insertListing(listing: MarketplaceListing): Long {
        return appDao.insertListing(listing)
    }
    
    suspend fun deleteListing(id: Int) {
        appDao.deleteListing(id)
    }
    
    suspend fun updateListingApproval(id: Int, approved: Boolean) {
        appDao.updateListingApproval(id, approved)
    }

    suspend fun updateListingFeaturedBottom(id: Int, featured: Boolean) {
        appDao.updateListingFeaturedBottom(id, featured)
    }

    // --- CMS Config Repo Methods ---
    val cmsConfig: Flow<CmsConfig?> = appDao.getCmsConfig()
    
    suspend fun insertCmsConfig(cmsConfig: CmsConfig) {
        appDao.insertCmsConfig(cmsConfig)
    }

    // --- Admin Analytics Repo Methods ---
    val adminAnalytics: Flow<AdminAnalytics?> = appDao.getAdminAnalytics()

    suspend fun incrementVisitsForum() = appDao.incrementVisitsForum()
    suspend fun incrementVisitsProCircle() = appDao.incrementVisitsProCircle()
    suspend fun incrementVisitsMarketplace() = appDao.incrementVisitsMarketplace()
    suspend fun incrementVisitsAiDiagnostics() = appDao.incrementVisitsAiDiagnostics()
    suspend fun incrementVisitsSettings() = appDao.incrementVisitsSettings()
    suspend fun incrementWhatsappClicks() = appDao.incrementWhatsappClicks()
    suspend fun incrementAiQuestionsCount() = appDao.incrementAiQuestionsCount()
    suspend fun incrementUpvotesGivenCount() = appDao.incrementUpvotesGivenCount()

    // --- Provider Rating Repo Methods ---
    val allRatingsGlobal: Flow<List<ProviderRating>> = appDao.getAllRatingsGlobal()

    fun getRatingsForProvider(providerId: String): Flow<List<ProviderRating>> {
        return appDao.getRatingsForProvider(providerId)
    }

    suspend fun insertRating(rating: ProviderRating): Long {
        return appDao.insertRating(rating)
    }

    suspend fun seedDatabase() = withContext(Dispatchers.IO) {
        com.example.data.local.AppDatabase.populateDatabase(appDao)
    }
}
