package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Smooth Futuristic Teal & Mint #00ebba (Glows on Dark Mode)
val VibrantTeal = Color(0xFF00EBBA)
val DeepTeal = Color(0xFF00BFA5)
val ElectricMint = Color(0xFF50FFDC)

// Sleek Garage Grays & Deep Charcoal
val CharcoalDarkState = Color(0xFF121212)
val CharcoalSurface = Color(0xFF1E1E1E)
val CharcoalBorder = Color(0xFF2E2E2E)

// Text and Accents
val HighContrastWhite = Color(0xFFF5F5F5)
val SubduedGray = Color(0xFF9E9E9E)
val MintVerified = Color(0xFF2E7D32)
val GlassyOverlay = Color(0x1F2E2E2E)
