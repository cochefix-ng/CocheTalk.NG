package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // --- User Queries ---
    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUser(id: String): User?

    @Query("SELECT * FROM users ORDER BY name ASC")
    fun getAllUsers(): Flow<List<User>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Query("UPDATE users SET verified = :verified WHERE id = :id")
    suspend fun updateUserVerification(id: String, verified: Boolean)

    @Query("UPDATE users SET isBanned = :isBanned WHERE id = :id")
    suspend fun updateUserBanned(id: String, isBanned: Boolean)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUser(id: String)

    // --- Question Queries ---
    @Query("SELECT * FROM questions ORDER BY timestamp DESC")
    fun getAllQuestions(): Flow<List<Question>>

    @Query("SELECT * FROM questions WHERE id = :id")
    fun getQuestionById(id: Int): Flow<Question?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuestion(question: Question): Long

    @Query("DELETE FROM questions WHERE id = :id")
    suspend fun deleteQuestion(id: Int)

    @Query("UPDATE questions SET upvotes = upvotes + 1 WHERE id = :id")
    suspend fun upvoteQuestion(id: Int)

    @Query("UPDATE questions SET acceptedAnswerId = :answerId WHERE id = :id")
    suspend fun acceptAnswerOnQuestion(id: Int, answerId: Int)

    // --- Answer Queries ---
    @Query("SELECT * FROM answers")
    fun getAllAnswersGlobal(): Flow<List<Answer>>

    @Query("SELECT * FROM answers WHERE questionId = :questionId ORDER BY timestamp ASC")
    fun getAnswersForQuestion(questionId: Int): Flow<List<Answer>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnswer(answer: Answer): Long

    @Query("DELETE FROM answers WHERE id = :id")
    suspend fun deleteAnswer(id: Int)

    @Query("UPDATE answers SET upvotes = upvotes + 1 WHERE id = :id")
    suspend fun upvoteAnswer(id: Int)

    @Query("UPDATE answers SET isAccepted = :isAccepted WHERE id = :id")
    suspend fun updateAnswerAccepted(id: Int, isAccepted: Boolean)

    // --- Comment Queries ---
    @Query("SELECT * FROM comments WHERE questionOrAnswerId = :parentId AND isAnswer = :isAnswer ORDER BY timestamp ASC")
    fun getComments(parentId: Int, isAnswer: Boolean): Flow<List<Comment>>

    @Query("SELECT * FROM comments ORDER BY timestamp DESC")
    fun getAllCommentsGlobal(): Flow<List<Comment>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertComment(comment: Comment): Long

    // --- Marketplace Queries ---
    @Query("SELECT * FROM marketplace_listings ORDER BY timestamp DESC")
    fun getAllListings(): Flow<List<MarketplaceListing>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertListing(listing: MarketplaceListing): Long

    @Query("DELETE FROM marketplace_listings WHERE id = :id")
    suspend fun deleteListing(id: Int)

    @Query("UPDATE marketplace_listings SET isApproved = :approved WHERE id = :id")
    suspend fun updateListingApproval(id: Int, approved: Boolean)

    @Query("UPDATE marketplace_listings SET isFeaturedBottom = :featured WHERE id = :id")
    suspend fun updateListingFeaturedBottom(id: Int, featured: Boolean)

    // --- CMS Config Queries ---
    @Query("SELECT * FROM cms_configs WHERE id = 'cms_singleton'")
    fun getCmsConfig(): Flow<CmsConfig?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCmsConfig(cmsConfig: CmsConfig)

    // --- Admin Analytics Queries ---
    @Query("SELECT * FROM admin_analytics WHERE id = 'analytics_singleton'")
    fun getAdminAnalytics(): Flow<AdminAnalytics?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAdminAnalytics(analytics: AdminAnalytics)

    @Query("UPDATE admin_analytics SET visitsForum = visitsForum + 1 WHERE id = 'analytics_singleton'")
    suspend fun incrementVisitsForum()

    @Query("UPDATE admin_analytics SET visitsProCircle = visitsProCircle + 1 WHERE id = 'analytics_singleton'")
    suspend fun incrementVisitsProCircle()

    @Query("UPDATE admin_analytics SET visitsMarketplace = visitsMarketplace + 1 WHERE id = 'analytics_singleton'")
    suspend fun incrementVisitsMarketplace()

    @Query("UPDATE admin_analytics SET visitsAiDiagnostics = visitsAiDiagnostics + 1 WHERE id = 'analytics_singleton'")
    suspend fun incrementVisitsAiDiagnostics()

    @Query("UPDATE admin_analytics SET visitsSettings = visitsSettings + 1 WHERE id = 'analytics_singleton'")
    suspend fun incrementVisitsSettings()

    @Query("UPDATE admin_analytics SET whatsappClicks = whatsappClicks + 1 WHERE id = 'analytics_singleton'")
    suspend fun incrementWhatsappClicks()

    @Query("UPDATE admin_analytics SET aiQuestionsCount = aiQuestionsCount + 1 WHERE id = 'analytics_singleton'")
    suspend fun incrementAiQuestionsCount()

    @Query("UPDATE admin_analytics SET upvotesGivenCount = upvotesGivenCount + 1 WHERE id = 'analytics_singleton'")
    suspend fun incrementUpvotesGivenCount()

    // --- Provider Rating Queries ---
    @Query("SELECT * FROM provider_ratings ORDER BY timestamp DESC")
    fun getAllRatingsGlobal(): Flow<List<ProviderRating>>

    @Query("SELECT * FROM provider_ratings WHERE providerId = :providerId ORDER BY timestamp DESC")
    fun getRatingsForProvider(providerId: String): Flow<List<ProviderRating>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRating(rating: ProviderRating): Long
}
