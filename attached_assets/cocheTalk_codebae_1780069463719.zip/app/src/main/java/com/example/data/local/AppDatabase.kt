package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        User::class,
        Question::class,
        Answer::class,
        Comment::class,
        MarketplaceListing::class,
        CmsConfig::class,
        AdminAnalytics::class,
        ProviderRating::class
    ],
    version = 8,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                try {
                    val instance = Room.databaseBuilder(
                        context.applicationContext,
                        AppDatabase::class.java,
                        "cochefix_database_v8"
                    )
                    .fallbackToDestructiveMigration(true)
                    .fallbackToDestructiveMigrationOnDowngrade(true)
                    .build()
                    INSTANCE = instance
                    instance
                } catch (e: Exception) {
                    try {
                        context.applicationContext.deleteDatabase("cochefix_database_v8")
                    } catch (ex: Exception) {
                        ex.printStackTrace()
                    }
                    val instance = Room.databaseBuilder(
                        context.applicationContext,
                        AppDatabase::class.java,
                        "cochefix_database_v8"
                    )
                    .fallbackToDestructiveMigration(true)
                    .fallbackToDestructiveMigrationOnDowngrade(true)
                    .build()
                    INSTANCE = instance
                    instance
                }
            }
        }

        suspend fun populateDatabase(dao: AppDao) {
            // 1. Seed CMS CONFIG
            dao.insertCmsConfig(CmsConfig())
            
            // Seed Admin Analytics
            dao.insertAdminAnalytics(AdminAnalytics())

            // 2. Seed Users
            val admin = User(
                id = "admin@cochefix.com",
                name = "Chief Administrator",
                email = "admin@cochefix.com",
                role = "Admin",
                verified = true,
                phone = "+234800000001",
                specialization = "Platform Management",
                businessName = "CocheFix HQ",
                experience = 5,
                location = "Abuja, Nigeria"
            )
            val jose = User(
                id = "jose@cochefix.com",
                name = "Jose Ramirez",
                email = "jose@cochefix.com",
                role = "Service Provider",
                verified = true,
                phone = "+15550199", // Simple test format, easily translates to WhatsApp
                specialization = "Engine & Tuning",
                businessName = "Jose Ramirez Auto Clinic",
                experience = 12,
                location = "Lagos, Nigeria"
            )
            val mike = User(
                id = "mike@cochefix.com",
                name = "Mike Adebayo",
                email = "mike@cochefix.com",
                role = "Service Provider",
                verified = true,
                phone = "+15550188",
                specialization = "Electrical & ECU Diagnostics",
                businessName = "SparkTech Diagnostics",
                experience = 8,
                location = "Abuja, Nigeria"
            )
            val samson = User(
                id = "samson@cochefix.com",
                name = "Samson Okafor",
                email = "samson@cochefix.com",
                role = "Service Provider",
                verified = false, // Unverified, so admin can manually verify him!
                phone = "+2348123456789",
                specialization = "Gearboxes & Transmissions",
                businessName = "Okafor Precision Works",
                experience = 15,
                location = "Port Harcourt, Nigeria"
            )
            val bisi = User(
                id = "bisi@cochefix.com",
                name = "Bisi Alao",
                email = "bisi@cochefix.com",
                role = "Car Owner",
                verified = false,
                phone = "+2347012345678",
                location = "Lagos, Nigeria"
            )

            dao.insertUser(admin)
            dao.insertUser(jose)
            dao.insertUser(mike)
            dao.insertUser(samson)
            dao.insertUser(bisi)

            // 3. Seed Q&A Forum Questions
            // Public Q1
            val q1Id = dao.insertQuestion(
                Question(
                    title = "Toyota Camry 2012 Cold Start Engine Knocking",
                    description = "Hi everyone, my Camry is making a consistent tap-tap/knocking sound when started cold. It completely goes away after driving for about 5 minutes. Oil levels look fine. What could be the cause of this?",
                    userId = bisi.id,
                    userName = bisi.name,
                    userRole = bisi.role,
                    userSpecialization = null,
                    userVerified = bisi.verified,
                    tags = "Toyota, Engine, Camry, Noise",
                    isPrivateEcosystem = false,
                    upvotes = 3,
                    acceptedAnswerId = -1
                )
            ).toInt()

            // Answer to Q1
            dao.insertAnswer(
                Answer(
                    questionId = q1Id,
                    userId = jose.id,
                    userName = jose.name,
                    userRole = jose.role,
                    userSpecialization = jose.specialization,
                    userVerified = jose.verified,
                    content = "This is a classical cold start issue on 2AR-FE engines. It is often caused by a failing VVT-i cam gear sprocket inside which slips before oil pressure builds up. Suggest using high-quality 5W-30 fully synthetic oil. If you are in Lagos, drive by my workshop and we can run a pressure test!",
                    upvotes = 4,
                    isAccepted = false
                )
            )

            // Public Q2
            val q2Id = dao.insertQuestion(
                Question(
                    title = "Subaru Forester Dashboard Lights Flashing After Battery Swap",
                    description = "I just put in a new battery in my Forester and now the Cruise Control, ABS, and Check Engine lights are all flashing on the dashboard simultaneously! Is it safe to drive, and how do I reset them?",
                    userId = bisi.id,
                    userName = bisi.name,
                    userRole = bisi.role,
                    userSpecialization = null,
                    userVerified = bisi.verified,
                    tags = "Subaru, Electrical, Diagnostic",
                    isPrivateEcosystem = false,
                    upvotes = 5,
                    acceptedAnswerId = -1
                )
            ).toInt()

            // Answers to Q2
            val a2Id = dao.insertAnswer(
                Answer(
                    questionId = q2Id,
                    userId = mike.id,
                    userName = mike.name,
                    userRole = mike.role,
                    userSpecialization = mike.specialization,
                    userVerified = mike.verified,
                    content = "In Subarus, when the primary Check Engine Light is triggered, the ECU purposefully disables the Traction Control and flashing Cruise Control lights as a safety warning. Disconnecting the battery resets the memory, causing a temporary throttle body position error. Let the engine idle without AC for 10 minutes to auto-calibrate. If it doesn't clear, get an OBD-II scan.",
                    upvotes = 7,
                    isAccepted = true
                )
            ).toInt()

            // Update Q2 to accept Mike's answer
            dao.acceptAnswerOnQuestion(q2Id, a2Id)

            // 4. Private Service-Provider Ecosystem Questions (MECHANICS TALKING TO MECHANICS)
            val privateQ1Id = dao.insertQuestion(
                Question(
                    title = "[Diagnostics] AUTEL Ultra vs Launch PAD VII in daily workshop use?",
                    description = "Hey fellas, looking to upgrade our primary shop scanner. The Autel Ultra has the modular oscilloscope which is neat, but the Launch has amazing topology mapping and faster coding. What is your experience in the field with CAN-FD and DoIP protocols?",
                    userId = jose.id,
                    userName = jose.name,
                    userRole = jose.role,
                    userSpecialization = jose.specialization,
                    userVerified = jose.verified,
                    tags = "Scanners, Tooling, Diagnostics",
                    isPrivateEcosystem = true, // Private ecosystem!
                    upvotes = 2,
                    acceptedAnswerId = -1
                )
            ).toInt()

            dao.insertAnswer(
                Answer(
                    questionId = privateQ1Id,
                    userId = mike.id,
                    userName = mike.name,
                    userRole = mike.role,
                    userSpecialization = mike.specialization,
                    userVerified = mike.verified,
                    content = "Jose, we run both at sparkTech. Honestly, for Euro cars (Mercedes/BMW), the Autel is more intuitive and its J2534 passthru is rock solid. But for Asian engines (Toyota, Nissan, Hyundai), Launch is way faster for active cylinder/injector tests. Go Autel if you can afford the extra subscription, otherwise Launch is bulletproof.",
                    upvotes = 3,
                    isAccepted = false
                )
            )

            // 5. Seed Marketplace Listings
            dao.insertListing(
                MarketplaceListing(
                    title = "Premium OEM Front Brake Pads - Toyota Corolla (2014-2019)",
                    description = "Brand new in box. Original Toyota manufactured front brake pad set. Ceramic compound for low dust and quiet braking performance.",
                    price = 45000.0,
                    userId = jose.id,
                    userName = jose.name,
                    userRole = jose.role,
                    userPhone = jose.phone,
                    category = "Parts",
                    location = jose.location,
                    imageUrl = "parts",
                    isApproved = true, // Already approved, ready to display!
                    partsGrade = "OEM",
                    application = "Toyota Corolla (2014-2019)",
                    partBrand = "Toyota OEM",
                    isFeaturedBottom = true
                )
            )

            dao.insertListing(
                MarketplaceListing(
                    title = "Professional Full Electronic Diagnostic OBD-II Scan",
                    description = "Having warning lights? Get a complete health report of your vehicle modules (ECU, ABS, SRS, Gearbox). Includes error clearing and specialized mechanical suggestions.",
                    price = 25000.0,
                    userId = mike.id,
                    userName = mike.name,
                    userRole = mike.role,
                    userPhone = mike.phone,
                    category = "Services",
                    location = mike.location,
                    imageUrl = "services",
                    isApproved = true // Already approved!
                )
            )

            dao.insertListing(
                MarketplaceListing(
                    title = "Heavy-Duty OBD-II Bluetooth Adapter & Mobile Software",
                    description = "Convert your phone into a powerful diagnostic tool. Reads real-time ECU parameters, logs sensor curves, and clears standard trouble codes instantly.",
                    price = 35000.0,
                    userId = samson.id,
                    userName = samson.name,
                    userRole = samson.role,
                    userPhone = samson.phone,
                    category = "Accessories",
                    location = samson.location,
                    imageUrl = "accessories",
                    isApproved = false // Awaiting approval! Admin can approve or reject this listing in dashboard.
                )
            )

            // 6. Seed Comments
            dao.insertComment(
                Comment(
                    questionOrAnswerId = q1Id,
                    isAnswer = false, // on question
                    userId = bisi.id,
                    userName = bisi.name,
                    content = "Wow thanks Jose, this gives me a solid starting point before I tow it anywhere!"
                )
            )
        }
    }
}
