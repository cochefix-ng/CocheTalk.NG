package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import androidx.compose.ui.layout.ContentScale
import com.example.data.model.*
import com.example.ui.MainViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun CocheFixApp(viewModel: MainViewModel) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    // Observe streams from MainViewModel
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val allQuestions by viewModel.allQuestions.collectAsStateWithLifecycle()
    val allAnswersGlobal by viewModel.allAnswersGlobal.collectAsStateWithLifecycle()
    val allListings by viewModel.allListings.collectAsStateWithLifecycle()
    val cmsConfig by viewModel.cmsConfig.collectAsStateWithLifecycle()

    val aiDiagnosticLoading by viewModel.aiDiagnosticLoading.collectAsStateWithLifecycle()
    val aiDiagnosticResult by viewModel.aiDiagnosticResult.collectAsStateWithLifecycle()

    // Screen State Management
    var currentTab by remember { mutableStateOf("forum") } // "forum", "private_eco", "marketplace", "ai_diagnostics", "settings"
    var selectedQuestionId by remember { mutableStateOf<Int?>(null) }
    var selectedSellerId by remember { mutableStateOf<String?>(null) }

    // Floating Form sheets toggle
    var showAskQuestionDialog by remember { mutableStateOf(false) }
    var showCreateListingDialog by remember { mutableStateOf(false) }
    var showRegisterOnboardingDialog by remember { mutableStateOf(false) }

    LaunchedEffect(currentTab) {
        viewModel.trackPageVisit(currentTab)
    }

    LaunchedEffect(currentUser) {
        if (currentUser?.role == "Car Owner" && currentTab == "private_eco") {
            currentTab = "forum"
        }
    }

    // Filter bindings
    val searchQuery by viewModel.forumSearchQuery.collectAsStateWithLifecycle()
    val activeFilter by viewModel.activeForumFilter.collectAsStateWithLifecycle()
    val activeTag by viewModel.activeForumTag.collectAsStateWithLifecycle()

    // Main App Frame Scaffold
    Scaffold(
        topBar = {
            Column {
                // Dynamic CMS Rolling Banner Text
                if (cmsConfig.bannerText.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.secondary,
                                        MaterialTheme.colorScheme.primary
                                    )
                                )
                            )
                            .padding(vertical = 6.dp, horizontal = 12.dp)
                    ) {
                        Text(
                            text = cmsConfig.bannerText,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Primary App Brand Header
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (!cmsConfig.logoUrl.isNullOrBlank()) {
                                Image(
                                    painter = rememberAsyncImagePainter(
                                        model = ImageRequest.Builder(LocalContext.current)
                                            .data(cmsConfig.logoUrl)
                                            .crossfade(true)
                                            .build()
                                    ),
                                    contentDescription = "Custom Logo",
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .size(32.dp)
                                        .clip(RoundedCornerShape(6.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Icon(
                                    imageVector = when (cmsConfig.logoIconName) {
                                        "Build" -> Icons.Filled.Build
                                        "ShoppingCart" -> Icons.Filled.ShoppingCart
                                        "Warning" -> Icons.Filled.Warning
                                        "Star" -> Icons.Filled.Star
                                        "Home" -> Icons.Filled.Home
                                        "Settings" -> Icons.Filled.Settings
                                        "Lock" -> Icons.Filled.Lock
                                        "Person" -> Icons.Filled.Person
                                        "Share" -> Icons.Filled.Share
                                        else -> Icons.Filled.Build
                                    },
                                    contentDescription = "Logo Indicator",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier
                                        .padding(end = 8.dp)
                                        .size(28.dp)
                                )
                            }
                            Text(
                                text = cmsConfig.logoText,
                                fontWeight = FontWeight.Black,
                                letterSpacing = (-1).sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    actions = {
                        // Testing simulator account switcher (extremely useful for AI Studio preview!)
                        var showAccountSwitcher by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { showAccountSwitcher = true }) {
                                Icon(
                                    imageVector = Icons.Filled.Person,
                                    contentDescription = "Switch Account Sim",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            DropdownMenu(
                                expanded = showAccountSwitcher,
                                onDismissRequest = { showAccountSwitcher = false }
                            ) {
                                Text(
                                    text = "⚡ QUICK SIMULATION LOGIN",
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(12.dp),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("Bisi Alao (Car Owner)") },
                                    onClick = {
                                        showAccountSwitcher = false
                                        val bisiUser = allUsers.find { it.id == "bisi@cochefix.com" }
                                        bisiUser?.let { viewModel.loginAsUser(it) }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Jose Ramirez (Verified Mech)") },
                                    onClick = {
                                        showAccountSwitcher = false
                                        val joseUser = allUsers.find { it.id == "jose@cochefix.com" }
                                        joseUser?.let { viewModel.loginAsUser(it) }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Samson Okafor (Unverified Pro)") },
                                    onClick = {
                                        showAccountSwitcher = false
                                        val samUser = allUsers.find { it.id == "samson@cochefix.com" }
                                        samUser?.let { viewModel.loginAsUser(it) }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Chief Admin") },
                                    onClick = {
                                        showAccountSwitcher = false
                                        val adminUser = allUsers.find { it.id == "admin@cochefix.com" }
                                        adminUser?.let { viewModel.loginAsUser(it) }
                                    }
                                )
                                HorizontalDivider()
                                DropdownMenuItem(
                                    text = { Text("➕ Register New Profile") },
                                    onClick = {
                                        showAccountSwitcher = false
                                        showRegisterOnboardingDialog = true
                                    }
                                )
                            }
                        }

                        // Label exhibiting the logged-in badge
                        currentUser?.let { user ->
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = user.name,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (user.verified) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = "Verified Badge",
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier
                                                .padding(start = 4.dp)
                                                .size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = user.role,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        } ?: run {
                            Button(
                                onClick = { showRegisterOnboardingDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.padding(end = 8.dp)
                            ) {
                                Text("Join", color = Color.Black)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )

                // CMS Announcement Text
                if (cmsConfig.announcementText.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(vertical = 4.dp, horizontal = 16.dp)
                    ) {
                        Text(
                            text = cmsConfig.announcementText,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            overflow = TextOverflow.Ellipsis,
                            maxLines = 1
                        )
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                windowInsets = WindowInsets.navigationBars
            ) {
                NavigationBarItem(
                    selected = currentTab == "forum" && selectedQuestionId == null,
                    onClick = {
                        currentTab = "forum"
                        selectedQuestionId = null
                        selectedSellerId = null
                    },
                    icon = { Icon(imageVector = Icons.Filled.Home, contentDescription = "Public Forum") },
                    label = { Text("Q&A Forum") }
                )

                if (currentUser?.role != "Car Owner") {
                    NavigationBarItem(
                        selected = currentTab == "private_eco",
                        onClick = {
                            currentTab = "private_eco"
                            selectedQuestionId = null
                            selectedSellerId = null
                        },
                        icon = {
                            Box {
                                Icon(imageVector = Icons.Filled.Lock, contentDescription = "Pro Circle")
                            }
                        },
                        label = { Text("Pro Circle") }
                    )
                }

                NavigationBarItem(
                    selected = currentTab == "marketplace" && selectedSellerId == null,
                    onClick = {
                        currentTab = "marketplace"
                        selectedQuestionId = null
                        selectedSellerId = null
                    },
                    icon = { Icon(imageVector = Icons.Filled.ShoppingCart, contentDescription = "Store") },
                    label = { Text("Marketplace") }
                )

                NavigationBarItem(
                    selected = currentTab == "ai_diagnostics",
                    onClick = {
                        currentTab = "ai_diagnostics"
                        selectedQuestionId = null
                        selectedSellerId = null
                    },
                    icon = { Icon(imageVector = Icons.Filled.Warning, contentDescription = "AI Diagnostics") },
                    label = { Text("AI Clinic") }
                )

                NavigationBarItem(
                    selected = currentTab == "settings",
                    onClick = {
                        currentTab = "settings"
                        selectedQuestionId = null
                        selectedSellerId = null
                    },
                    icon = { Icon(imageVector = Icons.Filled.Person, contentDescription = "Portal Hub") },
                    label = { Text(if (currentUser?.role == "Admin") "Admin" else "Profile") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.TopCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .widthIn(max = 840.dp)
                    .fillMaxWidth()
            ) {
                when {
                selectedQuestionId != null -> {
                    QuestionDetailPage(
                        questionId = selectedQuestionId!!,
                        viewModel = viewModel,
                        allAnswers = allAnswersGlobal,
                        onBack = { selectedQuestionId = null },
                        onViewSeller = { sellerId ->
                            selectedSellerId = sellerId
                            currentTab = "settings" // Redirect to look up profile
                            selectedQuestionId = null
                        }
                    )
                }
                selectedSellerId != null -> {
                    SellerProfileDetailPage(
                        sellerId = selectedSellerId!!,
                        viewModel = viewModel,
                        allUsers = allUsers,
                        allListings = allListings,
                        allQuestions = allQuestions,
                        onBack = { selectedSellerId = null }
                    )
                }
                else -> {
                    when (currentTab) {
                        "forum" -> ForumScreen(
                            viewModel = viewModel,
                            allQuestions = allQuestions,
                            allAnswers = allAnswersGlobal,
                            allListings = allListings,
                            onQuestionClick = { id -> selectedQuestionId = id },
                            onAskClick = {
                                if (currentUser == null) {
                                    showRegisterOnboardingDialog = true
                                    Toast.makeText(context, "Please create a profile first!", Toast.LENGTH_SHORT).show()
                                } else {
                                    showAskQuestionDialog = true
                                }
                            },
                            onProfileClick = { sellerId -> selectedSellerId = sellerId }
                        )
                        "private_eco" -> PrivateEcosystemScreen(
                            viewModel = viewModel,
                            currentUser = currentUser,
                            allQuestions = allQuestions,
                            allAnswers = allAnswersGlobal,
                            onQuestionClick = { id -> selectedQuestionId = id },
                            onAskClick = { showAskQuestionDialog = true },
                            onTriggerOnboard = { showRegisterOnboardingDialog = true }
                        )
                        "marketplace" -> MarketplaceScreen(
                            viewModel = viewModel,
                            currentUser = currentUser,
                            allListings = allListings,
                            onSellerClick = { sellerId -> selectedSellerId = sellerId },
                            onListClick = {
                                if (currentUser == null) {
                                    showRegisterOnboardingDialog = true
                                    Toast.makeText(context, "Please configure/login to list items", Toast.LENGTH_SHORT).show()
                                } else {
                                    showCreateListingDialog = true
                                }
                            }
                        )
                        "ai_diagnostics" -> AiDiagnosticsScreen(
                            loading = aiDiagnosticLoading,
                            result = aiDiagnosticResult,
                            onDiagnose = { desc -> viewModel.runAiDiagnostic(desc) },
                            onClear = { viewModel.clearAiDiagnostics() }
                        )
                        "settings" -> SettingsProfileAdminScreen(
                            viewModel = viewModel,
                            currentUser = currentUser,
                            allUsers = allUsers,
                            allListings = allListings,
                            allQuestions = allQuestions,
                            cmsConfig = cmsConfig,
                            onSellerSelected = { sellerId -> selectedSellerId = sellerId },
                            onRegisterTrigger = { showRegisterOnboardingDialog = true }
                        )
                    }
                }
            }
            }
        }
    }

    // --- Floating Ask Question Dialog ---
    if (showAskQuestionDialog) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var tags by remember { mutableStateOf("") }
        var isPrivate by remember { mutableStateOf(currentTab == "private_eco") }

        // Car details
        var yrModel by remember { mutableStateOf("") }
        var vehicleType by remember { mutableStateOf("") }

        // Sensory Vehicle Diagnosis Tips state
        var seeConcern by remember { mutableStateOf(false) }
        var hearConcern by remember { mutableStateOf(false) }
        var smellConcern by remember { mutableStateOf(false) }
        var feelConcern by remember { mutableStateOf(false) }
        var notStarting by remember { mutableStateOf(false) }
        var performanceConcern by remember { mutableStateOf(false) }
        var dashboardWarningLights by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAskQuestionDialog = false },
            title = { Text("Create Automotive Topic", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 560.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("What is the issue with your car?") },
                        placeholder = { Text("e.g. Toyota Corolla idling roughly") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("question_title_input")
                    )

                    // 1. Sensory Vehicle Diagnosis Tips Section
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                                shape = MaterialTheme.shapes.small
                            )
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "Sensory Vehicle Diagnosis Tips",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Help specialists diagnose by checking any applicable concerns:",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { seeConcern = !seeConcern }
                        ) {
                            Checkbox(checked = seeConcern, onCheckedChange = { seeConcern = it })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Is the vehicle concern related to what you see?", style = MaterialTheme.typography.bodySmall)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { hearConcern = !hearConcern }
                        ) {
                            Checkbox(checked = hearConcern, onCheckedChange = { hearConcern = it })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Is the vehicle concern related to what you hear?", style = MaterialTheme.typography.bodySmall)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { smellConcern = !smellConcern }
                        ) {
                            Checkbox(checked = smellConcern, onCheckedChange = { smellConcern = it })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Is the vehicle concern related to an odor you smell?", style = MaterialTheme.typography.bodySmall)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { feelConcern = !feelConcern }
                        ) {
                            Checkbox(checked = feelConcern, onCheckedChange = { feelConcern = it })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Is the vehicle concern related to what you feel?", style = MaterialTheme.typography.bodySmall)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { notStarting = !notStarting }
                        ) {
                            Checkbox(checked = notStarting, onCheckedChange = { notStarting = it })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Is the vehicle not starting?", style = MaterialTheme.typography.bodySmall)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { performanceConcern = !performanceConcern }
                        ) {
                            Checkbox(checked = performanceConcern, onCheckedChange = { performanceConcern = it })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Is the vehicle concern engine-performance related?", style = MaterialTheme.typography.bodySmall)
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { dashboardWarningLights = !dashboardWarningLights }
                        ) {
                            Checkbox(checked = dashboardWarningLights, onCheckedChange = { dashboardWarningLights = it })
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Do you have any warning lights on the dashboard?", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    // 2. Car details: Year Model and Vehicle Type
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = yrModel,
                            onValueChange = { yrModel = it },
                            label = { Text("Year Model") },
                            placeholder = { Text("e.g. 2018") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = vehicleType,
                            onValueChange = { vehicleType = it },
                            label = { Text("Vehicle Type") },
                            placeholder = { Text("e.g. Sedan, SUV") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Describe the mechanical symptoms") },
                        placeholder = { Text("List speed, when it occurs, smoke, knocking sounds, dashboard warnings...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("question_desc_input")
                    )

                    OutlinedTextField(
                        value = tags,
                        onValueChange = { tags = it },
                        label = { Text("Tags (comma separated)") },
                        placeholder = { Text("e.g. Toyota, Cylinder Misfire, rough idle") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (currentUser?.role == "Service Provider" || currentUser?.role == "Admin") {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clickable { isPrivate = !isPrivate }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(checked = isPrivate, onCheckedChange = { isPrivate = it })
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = "Post in Private Ecosystem",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Only other mechanicians can read or answer.",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isNotBlank() && description.isNotBlank()) {
                            viewModel.askQuestion(
                                title = title,
                                description = description,
                                tags = tags,
                                isPrivate = isPrivate,
                                yrModel = yrModel,
                                vehicleType = vehicleType,
                                seeConcern = seeConcern,
                                hearConcern = hearConcern,
                                smellConcern = smellConcern,
                                feelConcern = feelConcern,
                                notStarting = notStarting,
                                performanceConcern = performanceConcern,
                                dashboardWarningLights = dashboardWarningLights
                            )
                            showAskQuestionDialog = false
                            Toast.makeText(context, "Automotive question published!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Please fill in the title and description.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.testTag("submit_question_button")
                ) {
                    Text("Publish Thread", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAskQuestionDialog = false }) {
                    Text("Cancel", color = MaterialTheme.colorScheme.primary)
                }
            }
        )
    }

    // --- Floating Create Listing Dialog ---
    if (showCreateListingDialog) {
        var title by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var priceText by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Parts") }
        var location by remember { mutableStateOf("") }
        var partsGrade by remember { mutableStateOf("OEM") }
        var application by remember { mutableStateOf("") }
        var partBrand by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreateListingDialog = false },
            title = { Text("List Merchandise or Spare Part", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 560.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Listing Title") },
                        placeholder = { Text("e.g. Civic 2018 Front Struts Assembly") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("listing_title_input")
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("merchandise details / terms") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Asking Price (₦ NGN)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Column {
                        Text(
                            text = "Category",
                            style = MaterialTheme.typography.titleSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Parts", "Services", "Accessories").forEach { cat ->
                                FilterChip(
                                    selected = category == cat,
                                    onClick = { category = cat },
                                    label = { Text(cat) }
                                )
                            }
                        }
                    }

                    if (category == "Parts") {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Parts Grade",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("OEM", "OES", "Aftermarket Premium", "Aftermarket Economy").forEach { grade ->
                                    FilterChip(
                                        selected = partsGrade == grade,
                                        onClick = { partsGrade = grade },
                                        label = { Text(grade) }
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = application,
                            onValueChange = { application = it },
                            label = { Text("Application (Vehicle compatibility)") },
                            placeholder = { Text("e.g. Corolla 2009-2013, Camry 2012") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        OutlinedTextField(
                            value = partBrand,
                            onValueChange = { partBrand = it },
                            label = { Text("Part Brand") },
                            placeholder = { Text("e.g. Toyota, Denso, Bosch, Kyosan") },
                            modifier = Modifier.fillMaxWidth().testTag("part_brand_input")
                        )
                    }

                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("Pickup Location") },
                        placeholder = { Text("e.g. Lagos, Nigeria") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val priceNum = priceText.toDoubleOrNull() ?: 0.0
                        if (title.isNotBlank() && priceNum > 0 && location.isNotBlank()) {
                            viewModel.listProductOrService(
                                title = title,
                                description = description,
                                price = priceNum,
                                category = category,
                                location = location,
                                partsGrade = if (category == "Parts") partsGrade else "",
                                application = if (category == "Parts") application else "",
                                partBrand = if (category == "Parts") partBrand else ""
                            )
                            showCreateListingDialog = false
                            val message = if (currentUser?.role == "Admin") {
                                "Merchandise listed instantly!"
                            } else {
                                "Trade requested! Pending Admin manual catalog approval."
                            }
                            Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Fill all required bounds correctly.", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Publish Catalog", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateListingDialog = false }) {
                    Text("Cancel", color = MaterialTheme.colorScheme.primary)
                }
            }
        )
    }

    // --- Floating Onboarding / Register Dialog ---
    if (showRegisterOnboardingDialog) {
        var email by remember { mutableStateOf("") }
        var name by remember { mutableStateOf("") }
        var selectedRole by remember { mutableStateOf("Car Owner") } // "Car Owner" or "Service Provider"

        // Service Provider specific bindings
        var businessName by remember { mutableStateOf("") }
        var yearsExp by remember { mutableStateOf("") }
        var selectedSpecs by remember { mutableStateOf(setOf("General Mechanics")) }
        var location by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showRegisterOnboardingDialog = false },
            title = { Text("Register CocheFix Account", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 560.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("register_name_input")
                    )

                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email Address") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("register_email_input")
                    )

                    Text(
                        text = "Your Core Platform Role",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { selectedRole = "Car Owner" },
                            modifier = Modifier.weight(1f).testTag("select_owner_role"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedRole == "Car Owner") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Text("🚗 Car Owner", color = if (selectedRole == "Car Owner") Color.Black else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = { selectedRole = "Service Provider" },
                            modifier = Modifier.weight(1f).testTag("select_provider_role"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedRole == "Service Provider") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                            )
                        ) {
                            Text("🔧 Service Pro", color = if (selectedRole == "Service Provider") Color.Black else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    if (selectedRole == "Service Provider") {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = "Professional Account Specs",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                OutlinedTextField(
                                    value = businessName,
                                    onValueChange = { businessName = it },
                                    label = { Text("Workshop / Business Name") },
                                    modifier = Modifier.fillMaxWidth().testTag("biz_name_input")
                                )
                                OutlinedTextField(
                                    value = phone,
                                    onValueChange = { phone = it },
                                    label = { Text("WhatsApp Phone (e.g. +234...)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier.fillMaxWidth().testTag("register_phone_input")
                                )
                                OutlinedTextField(
                                    value = yearsExp,
                                    onValueChange = { yearsExp = it },
                                    label = { Text("Years of Experience") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = location,
                                    onValueChange = { location = it },
                                    label = { Text("Business Location City") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Text("Primary Area Specialties (Select multiple)", style = MaterialTheme.typography.labelSmall)
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.horizontalScroll(rememberScrollState())
                                ) {
                                    listOf("General Mechanics", "Engine Repair", "Electrical Systems", "Air Conditioning", "Transmissions", "Bodywork", "Key Programming", "Brakes & Suspension", "Hybrid / EV System").forEach { spec ->
                                        val isSel = selectedSpecs.contains(spec)
                                        FilterChip(
                                            selected = isSel,
                                            onClick = {
                                                selectedSpecs = if (isSel) {
                                                    selectedSpecs - spec
                                                } else {
                                                    selectedSpecs + spec
                                                }
                                            },
                                            label = { Text(spec) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (email.isNotBlank() && name.isNotBlank()) {
                            val expInt = yearsExp.toIntOrNull() ?: 3
                            val specsString = if (selectedSpecs.isEmpty()) "General Mechanics" else selectedSpecs.joinToString(", ")
                            viewModel.register(
                                email = email.trim(),
                                name = name.trim(),
                                role = selectedRole,
                                phone = phone.trim(),
                                specialization = specsString,
                                businessName = businessName.trim(),
                                experience = expInt,
                                location = location.trim()
                            )
                            showRegisterOnboardingDialog = false
                            Toast.makeText(context, "Account Created! Welcome to CocheFix.", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Please enter your name and email.", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Create Profile", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRegisterOnboardingDialog = false }) {
                    Text("Back", color = MaterialTheme.colorScheme.primary)
                }
            }
        )
    }
}

// ==========================================
// SCREEN 1: PUBLIC Q&A FORUM
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ForumScreen(
    viewModel: MainViewModel,
    allQuestions: List<Question>,
    allAnswers: List<Answer>,
    allListings: List<MarketplaceListing>,
    onQuestionClick: (Int) -> Unit,
    onAskClick: () -> Unit,
    onProfileClick: (String) -> Unit
) {
    val searchQuery by viewModel.forumSearchQuery.collectAsStateWithLifecycle()
    val activeFilter by viewModel.activeForumFilter.collectAsStateWithLifecycle()
    val activeTag by viewModel.activeForumTag.collectAsStateWithLifecycle()

    val filteredQuestions = remember(allQuestions, searchQuery, activeFilter, activeTag, allAnswers) {
        allQuestions
            // Do not show isPrivateEcosystem questions in public feed
            .filter { !it.isPrivateEcosystem }
            .filter { q ->
                (searchQuery.isBlank() || q.title.contains(searchQuery, ignoreCase = true) || q.description.contains(searchQuery, ignoreCase = true)) &&
                (activeTag.isEmpty() || q.tags.contains(activeTag, ignoreCase = true))
            }
            .let { list ->
                when (activeFilter) {
                    "Unanswered" -> {
                        list.filter { q ->
                            allAnswers.none { it.questionId == q.id }
                        }
                    }
                    "Most Answered" -> {
                        list.sortedByDescending { q ->
                            allAnswers.count { it.questionId == q.id }
                        }
                    }
                    else -> list // "Latest" -> already sorted timestamp DESC by default in DAO flow
                }
            }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Upper search panel
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.forumSearchQuery.value = it },
            placeholder = { Text("Search mechanical complaints, car models, errors...") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_input"),
            leadingIcon = { Icon(imageVector = Icons.Filled.Search, contentDescription = "Scan query") },
            trailingIcon = if (searchQuery.isNotEmpty()) {
                {
                    IconButton(onClick = { viewModel.forumSearchQuery.value = "" }) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Clear scan")
                    }
                }
            } else null
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Filters pills: Latest / Most Answered / Unanswered
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("Latest", "Most Answered", "Unanswered").forEach { filter ->
                FilterChip(
                    selected = activeFilter == filter,
                    onClick = { viewModel.activeForumFilter.value = filter },
                    label = { Text(filter) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }
        }

        // Active Tag Banner filter indication
        if (activeTag.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Active Tag Filter: ",
                    style = MaterialTheme.typography.bodySmall
                )
                AssistChip(
                    onClick = { viewModel.activeForumTag.value = "" },
                    label = { Text(activeTag) },
                    trailingIcon = { Icon(imageVector = Icons.Filled.Close, contentDescription = "Clear tag", modifier = Modifier.size(14.dp)) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Header Title + Ask CTA
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Dynamic Discussions (${filteredQuestions.size})",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Button(
                onClick = onAskClick,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = "Write topic", tint = Color.Black)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Ask Question", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Discussion Thread stream list
        if (filteredQuestions.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = "Empty discussions",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No complains found in CocheFix index.",
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Be the first to ask questions and consult our certified service-provider circle!",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(24.dp)
                    )
                    Button(onClick = { viewModel.forumSearchQuery.value = "" }) {
                        Text("Reset Search Filters")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredQuestions) { question ->
                    QuestionCardItem(
                        question = question,
                        allAnswers = allAnswers,
                        onClick = { onQuestionClick(question.id) },
                        onTagClick = { tag -> viewModel.activeForumTag.value = tag }
                    )
                }
            }
        }

        // Sleek dynamic rectangular ad slider banner at the bottom of the Q&A Forum Page
        val featuredAds = allListings.filter { it.isApproved && it.isFeaturedBottom }
        if (featuredAds.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            var activeAdIndex by remember(featuredAds) { mutableIntStateOf(0) }
            
            LaunchedEffect(featuredAds) {
                if (featuredAds.size > 1) {
                    while (true) {
                        kotlinx.coroutines.delay(4000)
                        activeAdIndex = (activeAdIndex + 1) % featuredAds.size
                    }
                }
            }
            
            val activeAd = featuredAds.getOrNull(activeAdIndex) ?: featuredAds[0]
            val context = LocalContext.current
            
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        onProfileClick(activeAd.userId)
                    },
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.95f)
                ),
                border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.8f))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primaryContainer,
                                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.6f)
                                    )
                                )
                            )
                    )
                    
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (activeAd.category) {
                                    "Parts" -> Icons.Filled.Build
                                    "Services" -> Icons.Filled.Star
                                    else -> Icons.Filled.ShoppingCart
                                },
                                contentDescription = "Active featured listing category marker",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(12.dp))
                        
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = activeAd.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            
                            Spacer(modifier = Modifier.height(2.dp))
                            
                            Text(
                                text = "₦${activeAd.price} | ${activeAd.location} | By: ${activeAd.userName}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            
                            Spacer(modifier = Modifier.height(2.dp))
                            
                            Text(
                                text = activeAd.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(8.dp))
                        
                        Column(
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.fillMaxHeight()
                        ) {
                            Badge(
                                containerColor = MaterialTheme.colorScheme.secondary,
                                contentColor = Color.Black
                            ) {
                                Text(
                                    text = "SPONSORED AD", 
                                    fontSize = 8.sp, 
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                            
                            Spacer(modifier = Modifier.weight(1f))
                            
                            if (featuredAds.size > 1) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.padding(bottom = 4.dp)
                                ) {
                                    featuredAds.forEachIndexed { index, _ ->
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    if (index == activeAdIndex)
                                                        MaterialTheme.colorScheme.primary
                                                    else
                                                        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                                                )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuestionCardItem(
    question: Question,
    allAnswers: List<Answer>,
    onClick: () -> Unit,
    onTagClick: (String) -> Unit
) {
    val qAnswers = remember(allAnswers, question.id) {
        allAnswers.filter { it.questionId == question.id }
    }
    val answersCount = qAnswers.size
    val isSolved = question.acceptedAnswerId != -1

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("question_item_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Upper row: Metadata and Solved badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.secondary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = question.userName.take(1).uppercase(),
                            color = Color.Black,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = question.userName,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (question.userVerified) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Verified Member",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier
                                .padding(start = 3.dp)
                                .size(12.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${question.userRole}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Solved check badge
                if (isSolved) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFE8F5E9))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Check,
                            contentDescription = "Solved checklist",
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "SOLVED",
                            color = Color(0xFF2E7D32),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Complaint Title
            Text(
                text = question.title,
                fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Car Specifications snippet if present
            if (question.yrModel.isNotEmpty() || question.vehicleType.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                val specs = listOfNotNull(
                    if (question.yrModel.isNotEmpty()) question.yrModel else null,
                    if (question.vehicleType.isNotEmpty()) question.vehicleType else null
                ).joinToString(" • ")
                Text(
                    text = "🚗 $specs",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Body Snippet
            Text(
                text = question.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            // List of Tags
            if (question.tags.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    question.tags.split(",").forEach { tag ->
                        val cleanTag = tag.trim()
                        if (cleanTag.isNotEmpty()) {
                            Text(
                                text = "#$cleanTag",
                                color = MaterialTheme.colorScheme.primary,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { onTagClick(cleanTag) }
                                    .padding(vertical = 2.dp, horizontal = 4.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))

            Spacer(modifier = Modifier.height(8.dp))

            // Lower Stats Indicators: Upvotes and comments count
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Posted " + SimpleDateFormat("MMM d, yyyy • HH:mm", Locale.getDefault()).format(question.timestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Upvotes
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.ThumbUp,
                            contentDescription = "Likes counter",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${question.upvotes}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Answers Count
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = "Answers counter",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$answersCount responses",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 2: PRIVATE MECHANICS/PROVIDERS CHANNEL
// ==========================================

@Composable
fun PrivateEcosystemScreen(
    viewModel: MainViewModel,
    currentUser: User?,
    allQuestions: List<Question>,
    allAnswers: List<Answer>,
    onQuestionClick: (Int) -> Unit,
    onAskClick: () -> Unit,
    onTriggerOnboard: () -> Unit
) {
    // Check if user has credentials
    val authorized = currentUser != null && (currentUser.role == "Service Provider" || currentUser.role == "Admin")

    if (!authorized) {
        // Gate overlay demonstrating Service Providers talking to Service Providers
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 500.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Lock Shield Indicator",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(72.dp)
                    )

                    Text(
                        text = "🔒 PRIVATE PRO CIRCLE",
                        fontWeight = FontWeight.Black,
                        style = MaterialTheme.typography.titleLarge,
                        letterSpacing = (-1).sp
                    )

                    Text(
                        text = "“Mechanics talk to mechanics without customer noise.”",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = "This channel is restricted to manual-verified workshop owners, technicians, and car tuners to share schematics, ECU diagnostic logs, tool advice, and workshop benchmarks.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    HorizontalDivider()

                    if (currentUser == null) {
                        Button(
                            onClick = onTriggerOnboard,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Create Service Provider Account", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                text = "Current User: ${currentUser.name}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Your role '${currentUser.role}' is not entitled to join Pro discussions.",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.error,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    } else {
        // Render private discussions feed!
        val privateQuestions = remember(allQuestions) {
            allQuestions.filter { it.isPrivateEcosystem }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Shield Guard icon",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "🛡️ You are inside the secure Pro Circle. Customer conversations are filtered out.",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ECU & Workshop Topics (${privateQuestions.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Button(
                    onClick = onAskClick,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(imageVector = Icons.Filled.Add, contentDescription = "Add topic icon", tint = Color.Black)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Pro Topic", color = Color.Black)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (privateQuestions.isEmpty()) {
                Box(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No engineering schematics logged yet. Tap 'Add Pro Topic' to consult other mechanics!",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(privateQuestions) { question ->
                        QuestionCardItem(
                            question = question,
                            allAnswers = allAnswers,
                            onClick = { onQuestionClick(question.id) },
                            onTagClick = { /* No-op in private */ }
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// SCREEN 3: MARKETPLACE SCREEN
// ==========================================

@Composable
fun MarketplaceScreen(
    viewModel: MainViewModel,
    currentUser: User?,
    allListings: List<MarketplaceListing>,
    onSellerClick: (String) -> Unit,
    onListClick: () -> Unit
) {
    var activeCategory by remember { mutableStateOf("All") }

    // Display only listings that are approved, except that Admins and the listing owners can see unapproved ones
    val filteredListings = remember(allListings, activeCategory, currentUser) {
        allListings
            .filter { listing ->
                listing.isApproved || currentUser?.role == "Admin" || currentUser?.id == listing.userId
            }
            .filter { listing ->
                activeCategory == "All" || listing.category == activeCategory
            }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Header titles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Spare Parts & Tuning Shop",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Verified service listings & original components",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = onListClick,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = "Add listing icon", tint = Color.Black)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Sell", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Grid filters: All, Parts, Services, Accessories
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf("All", "Parts", "Services", "Accessories").forEach { cat ->
                FilterChip(
                    selected = activeCategory == cat,
                    onClick = { activeCategory = cat },
                    label = { Text(cat) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Product Catalog items list
        if (filteredListings.isEmpty()) {
            Box(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.ShoppingCart,
                        contentDescription = "Empty store icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("No parts listed in this category.")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredListings) { item ->
                    MarketListingCard(
                        item = item,
                        currentUser = currentUser,
                        onDeleteClick = { viewModel.deleteListing(item.id) },
                        onSellerClick = { onSellerClick(item.userId) },
                        onWhatsappClick = { viewModel.trackWhatsappClick() }
                    )
                }
            }
        }
    }
}

@Composable
fun MarketListingCard(
    item: MarketplaceListing,
    currentUser: User?,
    onDeleteClick: () -> Unit,
    onSellerClick: () -> Unit,
    onWhatsappClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("marketplace_item_card"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Upper Header showing categories and pending tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.category.uppercase(),
                    color = MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!item.isApproved) {
                        AssistChip(
                            onClick = {},
                            label = { Text("Awaiting Admin verification", fontSize = 10.sp) },
                            colors = AssistChipDefaults.assistChipColors(containerColor = Color(0xFFFFF9C4))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    // Delete availability for Admin or Seller
                    if (currentUser?.role == "Admin" || currentUser?.id == item.userId) {
                        IconButton(onClick = onDeleteClick) {
                            Icon(imageVector = Icons.Filled.Close, contentDescription = "Delete merchant item", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pricing and Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = String.format(java.util.Locale.US, "₦%,.0f", item.price),
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.secondary,
                    style = MaterialTheme.typography.titleLarge
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description text
            Text(
                text = item.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (item.category.equals("Parts", ignoreCase = true)) {
                if (item.partsGrade.isNotBlank() || item.application.isNotBlank() || item.partBrand.isNotBlank()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (item.partBrand.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Brand: ${item.partBrand}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        if (item.partsGrade.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "Grade: ${item.partsGrade}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        if (item.application.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        color = MaterialTheme.colorScheme.tertiaryContainer,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                    .weight(1f, fill = false)
                            ) {
                                Text(
                                    text = "Fits: ${item.application}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Seller specifications bar
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onSellerClick),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = "Seller details avatar",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = "Merchant: ${item.userName}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "📍 ${item.location}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = "Visit profiles arrow icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Green WhatsApp communication CTA (Very important for Nigeria/Africa touchpoints!)
            Button(
                onClick = {
                    val encodedMessage = java.net.URLEncoder.encode(
                        "Hello, I found your listing '${item.title}' on CocheFix and would love to buy it.",
                        "UTF-8"
                    )
                    val whatsappUrl = "https://wa.me/${item.userPhone}?text=$encodedMessage"
                    onWhatsappClick()
                    try {
                        uriHandler.openUri(whatsappUrl)
                        Toast.makeText(context, "Opening instant WhatsApp chat...", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(context, "Link copied: wa.me/${item.userPhone}", Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("hire_me_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)) // WhatsApp Official color code
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Share,
                        contentDescription = "WhatsApp indicator icon",
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Order Instant via WhatsApp",
                        color = Color.White,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN 4: VEHICLE COMPLAINTS DIAGNOSTICS AI
// ==========================================

@Composable
fun AiDiagnosticsScreen(
    loading: Boolean,
    result: String?,
    onDiagnose: (String) -> Unit,
    onClear: () -> Unit
) {
    var issueText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Main Visual Card Header with cosmic dashboard background
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "🤖 COCHEFIX REAL-TIME AI DIAGNOSTICS",
                    fontWeight = FontWeight.Black,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )

                Text(
                    text = "Describe your vehicle's mechanical sound, warning light, or physical failure code. Gemini 3.5-Flash will instantly isolate likely failures and prepare professional repairs.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Complaint text box
        OutlinedTextField(
            value = issueText,
            onValueChange = { issueText = it },
            label = { Text("What symptoms is your vehicle presenting?") },
            placeholder = { Text("e.g., My Hyundai Elantra 2015 pedal vibrates when high-speed braking, and ABS warning emits after 10 miles...") },
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            maxLines = 5
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Operations CTA Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { onDiagnose(issueText) },
                enabled = issueText.isNotBlank() && !loading,
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                if (loading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black)
                } else {
                    Text("Trigger Analysis", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }

            OutlinedButton(
                onClick = {
                    issueText = ""
                    onClear()
                },
                enabled = !loading,
                modifier = Modifier.weight(0.5f)
            ) {
                Text("Reset")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Diagnostic layout panels output
        if (loading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Analyzing engine mappings & trouble models...",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        } else if (result != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🔧 DIAGNOSIS REPORT",
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.secondary,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = result,
                        style = MaterialTheme.typography.bodySmall,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

// ==========================================
// SCREEN 5: USER MANAGEMENT, MY PROFILE, & ADMIN CONTROL
// ==========================================

@Composable
fun SettingsProfileAdminScreen(
    viewModel: MainViewModel,
    currentUser: User?,
    allUsers: List<User>,
    allListings: List<MarketplaceListing>,
    allQuestions: List<Question>,
    cmsConfig: CmsConfig,
    onSellerSelected: (String) -> Unit,
    onRegisterTrigger: () -> Unit
) {
    val context = LocalContext.current
    if (currentUser == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = "Anonymous Shield icon",
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text("You are browsing anonymously.", fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick = onRegisterTrigger) {
                    Text("Register Profile", color = Color.Black)
                }
            }
        }
    } else {
        var adminMenuSection by remember { mutableStateOf("Moderation") } // "Moderation", "CMS", "Unapproved Listings"
        val adminAnalytics by viewModel.adminAnalytics.collectAsStateWithLifecycle()

        var showAdminUserEditDialog by remember { mutableStateOf(false) }
        var adminSelectedUserToEdit by remember { mutableStateOf<User?>(null) }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // First Section: User Profile parameters info card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = currentUser.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (currentUser.verified) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = "Verified expert confirmation",
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier
                                                .padding(start = 6.dp)
                                                .size(20.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = currentUser.email,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Button(
                                onClick = { viewModel.logout() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                            ) {
                                Text("LOG OUT")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        HorizontalDivider()

                        Spacer(modifier = Modifier.height(12.dp))

                        // Role details
                        Text(
                            text = "PROFILE ACCOUNT DETAILS",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text("• Role: ${currentUser.role}")
                        if (currentUser.role == "Service Provider") {
                            Text("• Specialty: ${currentUser.specialization}")
                            Text("• Business: ${currentUser.businessName}")
                            Text("• Phone: ${currentUser.phone}")
                            Text("• Years of Experience: ${currentUser.experience} years")
                            Text("• Location: ${currentUser.location}")
                        } else if (currentUser.location.isNotEmpty()) {
                            Text("• Location: ${currentUser.location}")
                        }

                        // System Reset Utilities for easy previewing and recovery
                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "DEVELOPMENT & SYSTEM CONTROLS",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = {
                                viewModel.resetDatabaseToDefaults(context)
                                Toast.makeText(context, "Database wiped and successfully seeded to defaults!", Toast.LENGTH_LONG).show()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.errorContainer,
                                contentColor = MaterialTheme.colorScheme.onErrorContainer
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("factory_reset_db_button")
                        ) {
                            Text("Reset & Seed Database To Defaults", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (currentUser.role == "Admin") {
                // Secondary Admin Operations panel
                item {
                    Text(
                        text = "⚙️ ADMINISTRATIVE SYSTEM CONSOLE",
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleSmall
                    )
                }

                item {
                    // Admin Selector Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Moderation", "CMS", "Unapproved Listings", "Analytics", "Data Export").forEach { section ->
                            FilterChip(
                                selected = adminMenuSection == section,
                                onClick = { adminMenuSection = section },
                                label = { Text(section) }
                            )
                        }
                    }
                }

                when (adminMenuSection) {
                    "Moderation" -> {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Manage Community Users (${allUsers.size})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                                Button(
                                    onClick = {
                                        adminSelectedUserToEdit = null
                                        showAdminUserEditDialog = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Add, 
                                        contentDescription = "Add User",
                                        modifier = Modifier.size(16.dp),
                                        tint = Color.Black
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add User", fontSize = 11.sp, color = Color.Black)
                                }
                            }
                        }
                        items(allUsers) { user ->
                            UserModerationCard(
                                user = user,
                                onToggleVerification = { verify -> viewModel.toggleUserVerification(user.id, verify) },
                                onToggleBan = { ban -> viewModel.toggleUserBanned(user.id, ban) },
                                onProfileClick = { onSellerSelected(user.id) },
                                onEditClick = {
                                    adminSelectedUserToEdit = user
                                    showAdminUserEditDialog = true
                                },
                                onDeleteClick = {
                                    viewModel.adminDeleteUser(user.id)
                                    Toast.makeText(context, "User profile deleted!", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                    "CMS" -> {
                        item {
                            CmsContentModeratorWidget(
                                currentCms = cmsConfig,
                                onSave = { logo, landing, banner, announcement, logoUrl, logoIcon ->
                                    viewModel.updateCmsConfig(logo, landing, banner, announcement, logoUrl, logoIcon)
                                }
                            )
                        }
                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Marketplace Feature Bottom Ads Management",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
                            )
                            Text(
                                text = "Feature approved marketplace listings or services as a dynamic rectangular slider banner at the bottom of the Forum page.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(horizontal = 4.dp).padding(bottom = 8.dp)
                            )
                        }
                        
                        val approvedListings = allListings.filter { it.isApproved }
                        if (approvedListings.isEmpty()) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = "No approved marketplace items found to feature.",
                                        modifier = Modifier.padding(16.dp),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            items(approvedListings) { listing ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (listing.isFeaturedBottom) 
                                            MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                        else 
                                            MaterialTheme.colorScheme.surface
                                    ),
                                    border = BorderStroke(
                                        width = if (listing.isFeaturedBottom) 2.dp else 1.dp,
                                        color = if (listing.isFeaturedBottom) 
                                            MaterialTheme.colorScheme.primary 
                                        else 
                                            MaterialTheme.colorScheme.outlineVariant
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = listing.title,
                                                    style = MaterialTheme.typography.titleSmall,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                if (listing.isFeaturedBottom) {
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    SuggestionChip(
                                                        onClick = {},
                                                        label = { Text("Featured Bottom", fontSize = 10.sp) },
                                                        icon = {
                                                            Icon(
                                                                imageVector = Icons.Filled.Star,
                                                                contentDescription = null,
                                                                modifier = Modifier.size(10.dp),
                                                                tint = MaterialTheme.colorScheme.primary
                                                            )
                                                        }
                                                    )
                                                }
                                            }
                                            Text(
                                                text = "Price: ₦${listing.price} | Category: ${listing.category}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Text(
                                                text = "Seller: ${listing.userName} (${listing.location})",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        
                                        Switch(
                                            checked = listing.isFeaturedBottom,
                                            onCheckedChange = { isChecked ->
                                                viewModel.toggleListingFeaturedBottom(listing.id, isChecked)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                    "Unapproved Listings" -> {
                        val pending = allListings.filter { !it.isApproved }
                        if (pending.isEmpty()) {
                            item {
                                Card(modifier = Modifier.fillMaxWidth()) {
                                    Text(
                                        text = "All listed parts and workshops catalog items have been moderated.",
                                        modifier = Modifier.padding(16.dp),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        } else {
                            items(pending) { item ->
                                PendingModerationMarketplaceCard(
                                    item = item,
                                    onApprove = { viewModel.approveMarketItem(item.id, true) },
                                    onReject = { viewModel.deleteListing(item.id) }
                                )
                            }
                        }
                    }
                    "Analytics" -> {
                        val carOwnersCount = allUsers.count { it.role == "Car Owner" }
                        val providersCount = allUsers.count { it.role == "Service Provider" }
                        val activeUsersCount = allUsers.count { !it.isBanned }
                        
                        val pageVisits = listOf(
                            "Public Forum" to adminAnalytics.visitsForum,
                            "Pro Circle" to adminAnalytics.visitsProCircle,
                            "Marketplace Store" to adminAnalytics.visitsMarketplace,
                            "AI Diagnostics" to adminAnalytics.visitsAiDiagnostics,
                            "Portal Hub / Settings" to adminAnalytics.visitsSettings
                        )
                        val maxVisits = pageVisits.maxOfOrNull { it.second } ?: 1
                        val mostlyVisitedPage = pageVisits.maxByOrNull { it.second }?.first ?: "N/A"
                        val mostlyVisitedValue = pageVisits.maxByOrNull { it.second }?.second ?: 0
                        
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Check,
                                        contentDescription = "Analytics overview icon",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "Core Platform Analytics",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Text(
                                            text = "Real-time telemetry gathered from user touchpoints.",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                            }
                        }

                        // Users Metrics
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "👥 MEMBERSHIP DEMOGRAPHICS",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                
                                ProportionBar(
                                    leftLabel = "Car Owners",
                                    leftCount = carOwnersCount,
                                    rightLabel = "Service Providers",
                                    rightCount = providersCount
                                )
                                
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(modifier = Modifier.weight(1.0f)) {
                                        MetricCard(
                                            title = "Car Owners",
                                            value = carOwnersCount.toString(),
                                            iconVector = Icons.Filled.Person,
                                            iconColor = MaterialTheme.colorScheme.primary,
                                            containerColor = MaterialTheme.colorScheme.surface
                                        )
                                    }
                                    Box(modifier = Modifier.weight(1.0f)) {
                                        MetricCard(
                                            title = "Service Providers",
                                            value = providersCount.toString(),
                                            iconVector = Icons.Filled.Check,
                                            iconColor = MaterialTheme.colorScheme.secondary,
                                            containerColor = MaterialTheme.colorScheme.surface
                                        )
                                    }
                                }
                                
                                MetricCard(
                                    title = "Total Active Users",
                                    value = activeUsersCount.toString(),
                                    subtitle = "Total users accessing platform without active ban status",
                                    iconVector = Icons.Filled.Person,
                                    iconColor = MaterialTheme.colorScheme.tertiary,
                                    containerColor = MaterialTheme.colorScheme.surface
                                )
                            }
                        }

                        // WhatsApp and AI Metrics
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "📈 ENGAGEMENT & ACQUISITIONS",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                                
                                MetricCard(
                                    title = "Instant Hire Clicks (WhatsApp)",
                                    value = adminAnalytics.whatsappClicks.toString(),
                                    subtitle = "Successful redirects to verified technicians or parts orders",
                                    iconVector = Icons.Filled.Share,
                                    iconColor = Color(0xFF25D366),
                                    containerColor = MaterialTheme.colorScheme.surface
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(modifier = Modifier.weight(1.0f)) {
                                        MetricCard(
                                            title = "Gemini AI Predictions",
                                            value = adminAnalytics.aiQuestionsCount.toString(),
                                            iconVector = Icons.Filled.Warning,
                                            iconColor = MaterialTheme.colorScheme.error,
                                            containerColor = MaterialTheme.colorScheme.surface
                                        )
                                    }
                                    Box(modifier = Modifier.weight(1.0f)) {
                                        MetricCard(
                                            title = "Total Upvotes Cast",
                                            value = adminAnalytics.upvotesGivenCount.toString(),
                                            iconVector = Icons.Filled.ThumbUp,
                                            iconColor = MaterialTheme.colorScheme.primary,
                                            containerColor = MaterialTheme.colorScheme.surface
                                        )
                                    }
                                }
                            }
                        }

                        // Page visits list
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(
                                        text = "📍 PAGE TRAFFIC METRICS",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    
                                    pageVisits.forEach { (page, count) ->
                                        PageTrafficBar(
                                            pageName = page,
                                            visits = count,
                                            maxVisits = maxVisits
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                                                shape = MaterialTheme.shapes.small
                                            )
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Home,
                                            contentDescription = "Mostly visited section",
                                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Most Visited: $mostlyVisitedPage ($mostlyVisitedValue visits)",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }
                    "Data Export" -> {
                        item {
                            DataExportConsoleWidget(
                                viewModel = viewModel,
                                allUsers = allUsers,
                                allListings = allListings,
                                allQuestions = allQuestions,
                                adminAnalytics = adminAnalytics
                            )
                        }
                    }
                }
            }
        }

        if (showAdminUserEditDialog) {
            AdminUserEditDialog(
                userToEdit = adminSelectedUserToEdit,
                onDismiss = { showAdminUserEditDialog = false },
                onSave = { editedUser ->
                    viewModel.adminSaveUserProfile(editedUser)
                    showAdminUserEditDialog = false
                    Toast.makeText(context, "User profile saved successfully!", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }
}

@Composable
fun UserModerationCard(
    user: User,
    onToggleVerification: (Boolean) -> Unit,
    onToggleBan: (Boolean) -> Unit,
    onProfileClick: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = user.name,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.clickable(onClick = onProfileClick)
                        )
                        if (user.verified) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = "verified",
                                tint = Color(0xFF2E7D32),
                                modifier = Modifier
                                    .padding(start = 4.dp)
                                    .size(14.dp)
                            )
                        }
                    }
                    Text(
                        text = "${user.role} • ${user.email}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Status indication labels and administrative Edit/Delete controls
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (user.isBanned) {
                        AssistChip(
                            onClick = {},
                            label = { Text("BANNED", style = MaterialTheme.typography.labelSmall) },
                            colors = AssistChipDefaults.assistChipColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    IconButton(onClick = onEditClick, modifier = Modifier.size(36.dp)) {
                        Icon(imageVector = Icons.Filled.Edit, contentDescription = "Edit Profile", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDeleteClick, modifier = Modifier.size(36.dp)) {
                        Icon(imageVector = Icons.Filled.Delete, contentDescription = "Delete Profile", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Verification toggle only for Service Providers
                if (user.role == "Service Provider") {
                    Button(
                        onClick = { onToggleVerification(!user.verified) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (user.verified) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.secondary
                        )
                    ) {
                        Text(
                            text = if (user.verified) "Strip Badge" else "Grant Verify Badge",
                            fontSize = 11.sp,
                            color = Color.Black
                        )
                    }
                }

                // Ban control
                Button(
                    onClick = { onToggleBan(!user.isBanned) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (user.isBanned) Color(0xFFC8E6C9) else MaterialTheme.colorScheme.error
                    )
                ) {
                    Text(
                        text = if (user.isBanned) "Reinstate User" else "Ban Account",
                        fontSize = 11.sp,
                        color = if (user.isBanned) Color.Black else Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun CmsContentModeratorWidget(
    currentCms: CmsConfig,
    onSave: (String, String, String, String, String, String) -> Unit
) {
    var logoText by remember(currentCms) { mutableStateOf(currentCms.logoText) }
    var landingText by remember(currentCms) { mutableStateOf(currentCms.landingText) }
    var bannerText by remember(currentCms) { mutableStateOf(currentCms.bannerText) }
    var announcementText by remember(currentCms) { mutableStateOf(currentCms.announcementText) }
    var logoUrl by remember(currentCms) { mutableStateOf(currentCms.logoUrl) }
    var logoIconName by remember(currentCms) { mutableStateOf(currentCms.logoIconName) }

    val context = LocalContext.current

    val iconOptions = listOf(
        "Build" to Icons.Filled.Build,
        "ShoppingCart" to Icons.Filled.ShoppingCart,
        "Warning" to Icons.Filled.Warning,
        "Star" to Icons.Filled.Star,
        "Home" to Icons.Filled.Home,
        "Settings" to Icons.Filled.Settings,
        "Lock" to Icons.Filled.Lock,
        "Person" to Icons.Filled.Person,
        "Share" to Icons.Filled.Share
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "CMS Settings Content Customization",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = logoText,
                onValueChange = { logoText = it },
                label = { Text("App Title / Logo Text") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = logoUrl,
                onValueChange = { logoUrl = it },
                label = { Text("Custom Pictorial Logo URL (https://...)") },
                placeholder = { Text("Paste image URL (png, jpg)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                supportingText = {
                    Text("Optional: Overrides the brand vector icon if specified.")
                }
            )

            if (!logoUrl.isBlank()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Live Logo Preview:",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                        Image(
                            painter = rememberAsyncImagePainter(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(logoUrl)
                                    .crossfade(true)
                                    .build()
                            ),
                            contentDescription = "Logo live preview representation",
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(6.dp)),
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }

            Text(
                text = "Alternative Preset Vector Icon",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(iconOptions) { (name, icon) ->
                    val isSelected = logoIconName == name
                    FilterChip(
                        selected = isSelected,
                        onClick = { logoIconName = name },
                        label = { Text(name, fontSize = 11.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = name,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    )
                }
            }

            OutlinedTextField(
                value = landingText,
                onValueChange = { landingText = it },
                label = { Text("Headline Statement") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = bannerText,
                onValueChange = { bannerText = it },
                label = { Text("Rolling Banner Announcement Text") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = announcementText,
                onValueChange = { announcementText = it },
                label = { Text("General Notifications Prompt") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    onSave(logoText, landingText, bannerText, announcementText, logoUrl, logoIconName)
                    Toast.makeText(context, "CMS configurations updated globally!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Update Layout & Logo Elements", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun PendingModerationMarketplaceCard(
    item: MarketplaceListing,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "PENDING CLASSIFIED: ${item.category.uppercase()}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(text = item.title, fontWeight = FontWeight.Bold)
            Text(text = String.format(java.util.Locale.US, "Asking ₦%,.0f • listed by %s in %s", item.price, item.userName, item.location), style = MaterialTheme.typography.bodySmall)

            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onApprove,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC8E6C9))
                ) {
                    Text("Approve Listing", fontSize = 11.sp, color = Color.Black)
                }

                Button(
                    onClick = onReject,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Text("Reject & Delete", fontSize = 11.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                }
            }
        }
    }
}

// ==========================================
// DRILL DOWN DETAIL PAGE (Q&A TOPICS)
// ==========================================

@Composable
fun QuestionDetailPage(
    questionId: Int,
    viewModel: MainViewModel,
    allAnswers: List<Answer>,
    onBack: () -> Unit,
    onViewSeller: (String) -> Unit
) {
    val context = LocalContext.current
    val keyboardController = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current

    val question = viewModel.allQuestions.collectAsStateWithLifecycle().value.find { it.id == questionId }
    val qAnswers = remember(allAnswers, questionId) {
        allAnswers.filter { it.questionId == questionId }
    }
    val commentsOnQuestionFlow = remember(questionId) {
        viewModel.getCommentsForParent(questionId, false)
    }
    val commentsOnQuestion by commentsOnQuestionFlow.collectAsStateWithLifecycle(emptyList())

    var answerInput by remember { mutableStateOf("") }
    var showCommentOnQuestionInput by remember { mutableStateOf(false) }
    var questionCommentInput by remember { mutableStateOf("") }

    if (question == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Issue thread has been deleted or is missing.")
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Back navigation
        item {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Return home")
            }
        }

        // Parent main query complain block
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = question.userName.take(1).uppercase(),
                                    color = Color.Black,
                                    fontWeight = FontWeight.Black
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = question.userName,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.clickable { onViewSeller(question.userId) }
                                    )
                                    if (question.userVerified) {
                                        Icon(
                                            imageVector = Icons.Filled.Check,
                                            contentDescription = "verified badge icon",
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier
                                                .padding(start = 4.dp)
                                                .size(12.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = question.userRole + (if (question.userSpecialization != null) " - ${question.userSpecialization}" else ""),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        // Upvote CTA
                        Button(
                            onClick = { viewModel.upvoteQuestion(question.id) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(imageVector = Icons.Filled.ThumbUp, contentDescription = "Upvote thread", tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+${question.upvotes}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = question.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Vehicle Details
                    if (question.yrModel.isNotEmpty() || question.vehicleType.isNotEmpty()) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                    shape = MaterialTheme.shapes.small
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = "Car specs icon",
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(14.dp)
                            )
                            val detailsText = listOfNotNull(
                                if (question.yrModel.isNotEmpty()) "Year: ${question.yrModel}" else null,
                                if (question.vehicleType.isNotEmpty()) "Type: ${question.vehicleType}" else null
                            ).joinToString(" | ")
                            Text(
                                text = detailsText,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    // Sensory Diagnosis check flags
                    val activeSensors = mutableListOf<String>()
                    if (question.seeConcern) activeSensors.add("👁️ See")
                    if (question.hearConcern) activeSensors.add("👂 Hear")
                    if (question.smellConcern) activeSensors.add("👃 Smell")
                    if (question.feelConcern) activeSensors.add("✋ Feel")
                    if (question.notStarting) activeSensors.add("❌ Not Starting")
                    if (question.performanceConcern) activeSensors.add("⚙️ Performance")
                    if (question.dashboardWarningLights) activeSensors.add("⚠️ Warning Lights")

                    if (activeSensors.isNotEmpty()) {
                        Column {
                            Text(
                                "Sensory Highlights:",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            // Wrap active sensors in a wrap or flow layout row
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                activeSensors.forEach { sensor ->
                                    Text(
                                        text = sensor,
                                        style = MaterialTheme.typography.labelSmall,
                                        modifier = Modifier
                                            .background(
                                                color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.8f),
                                                shape = MaterialTheme.shapes.small
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp),
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }

                    Text(
                        text = question.description,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Tags row
                    if (question.tags.isNotEmpty()) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            question.tags.split(",").forEach { tag ->
                                Text(text = "#${tag.trim()}", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    HorizontalDivider()

                    Spacer(modifier = Modifier.height(6.dp))

                    // Direct thread comment CTA
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showCommentOnQuestionInput = !showCommentOnQuestionInput }) {
                            Text(
                                text = if (showCommentOnQuestionInput) "Fold Comment Box" else "✍️ Comment on complain",
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Text(
                            text = SimpleDateFormat("MMM d, yyyy HH:mm", Locale.getDefault()).format(question.timestamp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    }

                    if (showCommentOnQuestionInput) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = questionCommentInput,
                                onValueChange = { questionCommentInput = it },
                                placeholder = { Text("Comment on symptom details...") },
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = {
                                    if (questionCommentInput.isNotBlank()) {
                                        viewModel.addComment(question.id, false, questionCommentInput)
                                        questionCommentInput = ""
                                        showCommentOnQuestionInput = false
                                        keyboardController?.hide()
                                    }
                                }
                            ) {
                                Text("Send", color = Color.Black)
                            }
                        }
                    }

                    // Render child question comments list
                    if (commentsOnQuestion.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("COMMENTS", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.secondary)
                                commentsOnQuestion.forEach { comment ->
                                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                        Row {
                                            Text(text = comment.userName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(text = comment.content, style = MaterialTheme.typography.bodySmall)
                                        }
                                        HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section header for responses
        item {
            Text(
                text = "Professional Responses (${qAnswers.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        // Answers responses listing
        if (qAnswers.isEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No workshop specialist has answered yet. Use our diagnostic assistant in the interim!",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(qAnswers) { answer ->
                AnswerItemWidget(
                    answer = answer,
                    question = question,
                    viewModel = viewModel,
                    onViewSeller = onViewSeller
                )
            }
        }

        // Create answer writing space
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("answer_input_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Propose workshop repair suggestion",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = answerInput,
                        onValueChange = { answerInput = it },
                        placeholder = { Text("List diagnostics, trouble checks, parts codes...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                            .testTag("answer_input")
                    )

                    Button(
                        onClick = {
                            if (answerInput.isNotBlank()) {
                                viewModel.answerQuestion(question.id, answerInput)
                                answerInput = ""
                                Toast.makeText(context, "Response added to thread index!", Toast.LENGTH_SHORT).show()
                                keyboardController?.hide()
                            } else {
                                Toast.makeText(context, "Fill the answer content.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("submit_answer_button")
                    ) {
                        Text("Publish Answer", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AnswerItemWidget(
    answer: Answer,
    question: Question,
    viewModel: MainViewModel,
    onViewSeller: (String) -> Unit
) {
    val commentsOnAnswerFlow = remember(answer.id) {
        viewModel.getCommentsForParent(answer.id, true)
    }
    val commentsOnAnswer by commentsOnAnswerFlow.collectAsStateWithLifecycle(emptyList())

    var showCommentInput by remember { mutableStateOf(false) }
    var commentText by remember { mutableStateOf("") }

    val isAuthorOfQuestion = viewModel.currentUser.value?.id == question.userId
    val isSolvedOnParent = question.acceptedAnswerId != -1

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (answer.isAccepted) Color(0xFFF1F8E9) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            1.dp,
            if (answer.isAccepted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.outline
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Upper row: Spec details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = answer.userName.take(1).uppercase(),
                            color = Color.Black,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = answer.userName,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { onViewSeller(answer.userId) }
                            )
                            if (answer.userVerified) {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = "Verified expert badge",
                                    tint = Color(0xFF2E7D32),
                                    modifier = Modifier
                                        .padding(start = 4.dp)
                                        .size(12.dp)
                                )
                            }
                        }
                        Text(
                            text = answer.userRole + (if (answer.userSpecialization != null) " - ${answer.userSpecialization}" else ""),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                // If accepted, show solve label. If question author and no solve, offer solve button!
                if (answer.isAccepted) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFF2E7D32))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.Check, contentDescription = "Accepted banner icon", tint = Color.White, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("BEST SOLUTION", color = Color.White, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Black)
                    }
                } else if (isAuthorOfQuestion && !isSolvedOnParent) {
                    OutlinedButton(
                        onClick = { viewModel.acceptAnswer(question.id, answer.id) },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Accept Solution", fontSize = 10.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Answer Content
            Text(text = answer.content, style = MaterialTheme.typography.bodySmall, lineHeight = 20.sp)

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.upvoteAnswer(answer.id) }) {
                        Icon(imageVector = Icons.Filled.ThumbUp, contentDescription = "Upvote answer", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    Text("+${answer.upvotes}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }

                TextButton(onClick = { showCommentInput = !showCommentInput }) {
                    Text(
                        text = if (showCommentInput) "Cancel Comment" else "✍️ Comment",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            if (showCommentInput) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = commentText,
                        onValueChange = { commentText = it },
                        placeholder = { Text("Comment on recommendation details...") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            if (commentText.isNotBlank()) {
                                viewModel.addComment(answer.id, true, commentText)
                                commentText = ""
                                showCommentInput = false
                            }
                        }
                    ) {
                        Text("Send", color = Color.Black)
                    }
                }
            }

            // Answer Comments List rendering
            if (commentsOnAnswer.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                        .padding(8.dp)
                ) {
                    commentsOnAnswer.forEach { comm ->
                        Row(modifier = Modifier.padding(vertical = 2.dp)) {
                            Text(
                                text = comm.userName + ": ",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(text = comm.content, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// DRILL DOWN DETAIL PAGE (SELLER PROFILE)
// ==========================================

@Composable
fun SellerProfileDetailPage(
    sellerId: String,
    viewModel: MainViewModel,
    allUsers: List<User>,
    allListings: List<MarketplaceListing>,
    allQuestions: List<Question>,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allRatings by viewModel.allRatingsGlobal.collectAsStateWithLifecycle()

    val seller = remember(allUsers, sellerId) { allUsers.find { it.id == sellerId } }
    val listings = remember(allListings, sellerId) { allListings.filter { it.userId == sellerId } }
    val questions = remember(allQuestions, sellerId) { allQuestions.filter { it.userId == sellerId } }
    val sellerRatings = remember(allRatings, sellerId) { allRatings.filter { it.providerId == sellerId } }

    if (seller == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Mechanician profile not found.")
        }
        return
    }

    // Dynamic rating calculation combined with seed rating for verified experts
    val hasManualRating = seller.verified
    val defaultRatingValue = if (hasManualRating) 4.9 else 0.0
    val defaultRatingCount = if (hasManualRating) 24 else 0

    val dynamicallyAddedCount = sellerRatings.size
    val dynamicallyAddedSum = sellerRatings.sumOf { it.ratingValue }

    val totalCount = defaultRatingCount + dynamicallyAddedCount
    val averageRating = if (totalCount > 0) {
        val totalSum = (defaultRatingCount * defaultRatingValue) + dynamicallyAddedSum
        totalSum / totalCount
    } else {
        0.0
    }
    val formattedRating = if (totalCount > 0) String.format(java.util.Locale.US, "%.1f", averageRating) else "No rating"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IconButton(onClick = onBack) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back navigation arrow icon")
        }

        // Custom Profile Hero Canvas Layout
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
        ) {
            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = seller.name.take(1).uppercase(), fontSize = 28.sp, color = Color.Black, fontWeight = FontWeight.Black)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = seller.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    if (seller.verified) {
                        Icon(imageVector = Icons.Filled.Check, contentDescription = "Verified expert", tint = Color(0xFF2E7D32), modifier = Modifier.padding(start = 4.dp).size(20.dp))
                    }
                }

                Text(text = seller.role, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(10.dp))

                // Specialized rating display (combining static badge + user reviews)
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (totalCount > 0) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                        .padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Filled.Star, contentDescription = "Ratings star icon", tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (totalCount > 0) "$formattedRating ★ ($totalCount verified reviews)" else "No review ratings yet",
                        color = if (totalCount > 0) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                Spacer(modifier = Modifier.height(14.dp))

                // Detail grid fields
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.Start) {
                    if (seller.role == "Service Provider") {
                        ProfileSpecLabel("Business Name", seller.businessName)
                        ProfileSpecLabel("Specialization", seller.specialization)
                        ProfileSpecLabel("Years of Experience", "${seller.experience} years of diagnostics")
                        ProfileSpecLabel("Primary Workshop Base", seller.location)
                    } else {
                        ProfileSpecLabel("General base city", seller.location.ifEmpty { "N/A" })
                    }
                }

                // Call-To-Action WhatsApp Button ONLY visible for verified providers
                if (seller.role == "Service Provider" && seller.verified) {
                    Spacer(modifier = Modifier.height(16.dp))

                    val contextPhone = seller.phone.ifEmpty { "+15550199" }
                    Button(
                        onClick = {
                            val encodedMsg = java.net.URLEncoder.encode(
                                "Hello ${seller.name}, I found you on CocheFix and need your service.",
                                "UTF-8"
                            )
                            val waLink = "https://wa.me/$contextPhone?text=$encodedMsg"
                            viewModel.trackWhatsappClick()
                            try {
                                uriHandler.openUri(waLink)
                                Toast.makeText(context, "Redirecting to WhatsApp...", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Chat URL: wa.me/$contextPhone", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        modifier = Modifier.fillMaxWidth().testTag("hire_me_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Filled.Share, contentDescription = "WhatsApp indicator icon", tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Hire Specialist Instantly (WhatsApp)", color = Color.White, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        // --- Rating & Review Input Form (Visible for logged-in Users rating Service Providers) ---
        if (seller.role == "Service Provider" && currentUser != null && currentUser?.id != seller.id) {
            var inputRating by remember { mutableStateOf(5) }
            var reviewFeedback by remember { mutableStateOf("") }

            Card(
                modifier = Modifier.fillMaxWidth().testTag("add_rating_card"),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Rate this Service Provider",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Your rating can assist other car owners in finding verified and trustworthy mechanics.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // Interactive Star Row using colors for selection state
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        (1..5).forEach { star ->
                            val isSelected = star <= inputRating
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = "$star Stars Rating Choice",
                                tint = if (isSelected) Color(0xFFFFB300) else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f),
                                modifier = Modifier
                                    .size(32.dp)
                                    .clickable { inputRating = star }
                                    .testTag("star_icon_$star")
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (inputRating) {
                                1 -> "Disliked"
                                2 -> "Below Average"
                                3 -> "Average"
                                4 -> "Great Service"
                                5 -> "Superb Diagnostic!"
                                else -> ""
                            },
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    OutlinedTextField(
                        value = reviewFeedback,
                        onValueChange = { reviewFeedback = it },
                        label = { Text("Describe your diagnostics experience...") },
                        placeholder = { Text("E.g., Very professional workshop base and fast diagnosis!") },
                        modifier = Modifier.fillMaxWidth().testTag("review_feedback_field"),
                        maxLines = 3
                    )

                    Button(
                        onClick = {
                            if (reviewFeedback.trim().isEmpty()) {
                                Toast.makeText(context, "Please write review comments before submitting.", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.addProviderRating(
                                    providerId = seller.id,
                                    raterId = currentUser?.id ?: "anonymous",
                                    raterName = currentUser?.name ?: "Anonymous",
                                    ratingValue = inputRating,
                                    feedback = reviewFeedback.trim()
                                )
                                reviewFeedback = ""
                                inputRating = 5
                                Toast.makeText(context, "Review successfully submitted! Thank you.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.align(Alignment.End).testTag("submit_review_button")
                    ) {
                        Text("Submit Review")
                    }
                }
            }
        }

        // --- Reviews List Section ---
        if (seller.role == "Service Provider") {
            Text(
                text = "Owner Reviews & Feedback (${sellerRatings.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 8.dp)
            )

            if (sellerRatings.isEmpty()) {
                Text(
                    text = "No user-submitted comments yet. Be the first to rate José or SparkTech experts!",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                sellerRatings.forEach { review ->
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("user_review_${review.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = review.raterName,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                    (1..5).forEach { star ->
                                        Icon(
                                            imageVector = Icons.Filled.Star,
                                            contentDescription = "Review dynamic Star display",
                                            tint = if (star <= review.ratingValue) Color(0xFFFFB300) else Color.LightGray.copy(alpha = 0.4f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = review.feedback,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            val sdf = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                            val dateStr = try { sdf.format(Date(review.timestamp)) } catch(e: Exception) { "Recent" }
                            Text(
                                text = "Submitted on $dateStr",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }
        }

        // Listings published by this Seller
        Text(text = "Merchandise Publications (${listings.size})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        if (listings.isEmpty()) {
            Text("No parts or services listed by this merchant currently.", style = MaterialTheme.typography.bodySmall)
        } else {
            listings.forEach { item ->
                MarketListingCard(
                    item = item,
                    currentUser = viewModel.currentUser.value,
                    onDeleteClick = { viewModel.deleteListing(item.id) },
                    onSellerClick = {},
                    onWhatsappClick = { viewModel.trackWhatsappClick() }
                )
            }
        }
    }
}

@Composable
fun ProfileSpecLabel(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        Text(text = value, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String? = null,
    iconVector: androidx.compose.ui.graphics.vector.ImageVector? = null,
    iconColor: androidx.compose.ui.graphics.Color,
    containerColor: androidx.compose.ui.graphics.Color
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = containerColor),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                if (iconVector != null) {
                    Icon(
                        imageVector = iconVector,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (subtitle != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun ProportionBar(
    leftLabel: String,
    leftCount: Int,
    rightLabel: String,
    rightCount: Int
) {
    val total = leftCount + rightCount
    val leftPercent = if (total > 0) (leftCount.toFloat() / total) else 0.5f
    
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$leftLabel ($leftCount)",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "$rightLabel ($rightCount)",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        // Modern custom progress bar showing proportions
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.extraSmall
                )
        ) {
            Row(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(leftPercent.coerceIn(0.01f, 0.99f))
                        .background(
                            color = MaterialTheme.colorScheme.primary,
                            shape = RoundedCornerShape(topStart = 4.dp, bottomStart = 4.dp)
                        )
                )
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight((1f - leftPercent).coerceIn(0.01f, 0.99f))
                        .background(
                            color = MaterialTheme.colorScheme.secondary,
                            shape = RoundedCornerShape(topEnd = 4.dp, bottomEnd = 4.dp)
                        )
                )
            }
        }
    }
}

@Composable
fun PageTrafficBar(
    pageName: String,
    visits: Int,
    maxVisits: Int
) {
    val progress = if (maxVisits > 0) (visits.toFloat() / maxVisits) else 0f
    
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = pageName,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "$visits visits",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.extraSmall
                )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(progress.coerceIn(0.01f, 1.0f))
                    .background(
                        color = MaterialTheme.colorScheme.primary,
                        shape = MaterialTheme.shapes.extraSmall
                    )
            )
        }
    }
}

@Composable
fun AdminUserEditDialog(
    userToEdit: User?, // If null, we are ADDING a new user. If non-null, we are EDITING.
    onDismiss: () -> Unit,
    onSave: (User) -> Unit
) {
    var email by remember { mutableStateOf(userToEdit?.email ?: "") }
    var name by remember { mutableStateOf(userToEdit?.name ?: "") }
    var role by remember { mutableStateOf(userToEdit?.role ?: "Car Owner") } // "Car Owner", "Service Provider", "Admin"
    var verified by remember { mutableStateOf(userToEdit?.verified ?: false) }
    var phone by remember { mutableStateOf(userToEdit?.phone ?: "") }
    
    val specOptions = listOf(
        "General Mechanics", 
        "Engine Repair", 
        "Electrical Systems", 
        "Air Conditioning", 
        "Transmissions", 
        "Bodywork", 
        "Key Programming", 
        "Brakes & Suspension", 
        "Hybrid / EV System"
    )
    
    val initialSpecs = userToEdit?.specialization?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
    var selectedSpecs by remember { mutableStateOf(initialSpecs.toSet()) }

    var businessName by remember { mutableStateOf(userToEdit?.businessName ?: "") }
    var yearsExp by remember { mutableStateOf(userToEdit?.experience?.toString() ?: "3") }
    var location by remember { mutableStateOf(userToEdit?.location ?: "") }
    var isBanned by remember { mutableStateOf(userToEdit?.isBanned ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (userToEdit == null) "Add User Profile" else "Edit User Profile",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address (Unique ID)") },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = userToEdit == null // lock email for existing users
                )

                Text("Platform Role", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Car Owner", "Service Provider", "Admin").forEach { r ->
                        val isSel = role == r
                        Button(
                            onClick = { role = r },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(r, fontSize = 10.sp, color = if (isSel) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = verified, onCheckedChange = { verified = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Verified Professional Badge", style = MaterialTheme.typography.bodySmall)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = isBanned, onCheckedChange = { isBanned = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Banned Account Status", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }

                if (role == "Service Provider") {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "Service Provider Details",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )

                            OutlinedTextField(
                                value = businessName,
                                onValueChange = { businessName = it },
                                label = { Text("Workshop / Business Name") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("WhatsApp Phone (e.g. +234...)") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            OutlinedTextField(
                                value = yearsExp,
                                onValueChange = { yearsExp = it },
                                label = { Text("Years of Experience") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Text("Primary Specialties (Select Multiple)", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                specOptions.forEach { spec ->
                                    val isSel = selectedSpecs.contains(spec)
                                    FilterChip(
                                        selected = isSel,
                                        onClick = {
                                            selectedSpecs = if (isSel) {
                                                selectedSpecs - spec
                                            } else {
                                                selectedSpecs + spec
                                            }
                                        },
                                        label = { Text(spec, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Location City") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (email.isNotBlank() && name.isNotBlank()) {
                         val specsString = if (role == "Service Provider") {
                             if (selectedSpecs.isEmpty()) "General Mechanics" else selectedSpecs.joinToString(", ")
                         } else {
                             ""
                         }
                         val u = User(
                             id = email.trim(),
                             name = name.trim(),
                             email = email.trim(),
                             role = role,
                             verified = verified,
                             phone = phone.trim(),
                             specialization = specsString,
                             businessName = businessName.trim(),
                             experience = yearsExp.toIntOrNull() ?: 3,
                             location = location.trim(),
                             isBanned = isBanned
                         )
                         onSave(u)
                    }
                }
            ) {
                Text("Save Profile", color = Color.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.primary)
            }
        }
    )
}

// --- HELPER FORMATTING UTILITIES FOR DATA EXPORTS ---
private fun escapeCsv(value: Any?): String {
    val str = value?.toString() ?: ""
    val clean = str.replace("\"", "\"\"").replace("\n", " ")
    return if (clean.contains(",") || clean.contains("\"")) "\"$clean\"" else clean
}

private fun escapeJson(value: Any?): String {
    return (value?.toString() ?: "")
        .replace("\\", "\\\\")
        .replace("\"", "\\\"")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
}

// --- EXPORT DATASETS GENERATION HELPERS ---
private fun generateUsersCsv(users: List<User>): String {
    val sb = StringBuilder()
    sb.append("ID,Name,Email,Role,BusinessName,Experience,Specialization,Location,Phone,Verified,Banned\n")
    users.forEach { u ->
        sb.append("${escapeCsv(u.id)},${escapeCsv(u.name)},${escapeCsv(u.email)},${escapeCsv(u.role)},${escapeCsv(u.businessName)},${u.experience},${escapeCsv(u.specialization)},${escapeCsv(u.location)},${escapeCsv(u.phone)},${u.verified},${u.isBanned}\n")
    }
    return sb.toString()
}

private fun generateUsersJson(users: List<User>): String {
    val sb = StringBuilder()
    sb.append("[\n")
    users.forEachIndexed { i, u ->
        sb.append("  {\n")
        sb.append("    \"id\": \"${escapeJson(u.id)}\",\n")
        sb.append("    \"name\": \"${escapeJson(u.name)}\",\n")
        sb.append("    \"email\": \"${escapeJson(u.email)}\",\n")
        sb.append("    \"role\": \"${escapeJson(u.role)}\",\n")
        sb.append("    \"businessName\": \"${escapeJson(u.businessName)}\",\n")
        sb.append("    \"experience\": ${u.experience},\n")
        sb.append("    \"specialization\": \"${escapeJson(u.specialization)}\",\n")
        sb.append("    \"location\": \"${escapeJson(u.location)}\",\n")
        sb.append("    \"phone\": \"${escapeJson(u.phone)}\",\n")
        sb.append("    \"verified\": ${u.verified},\n")
        sb.append("    \"isBanned\": ${u.isBanned}\n")
        sb.append("  }${if (i < users.lastIndex) "," else ""}\n")
    }
    sb.append("]")
    return sb.toString()
}

private fun generateQuestionsCsv(questions: List<Question>): String {
    val sb = StringBuilder()
    sb.append("ID,Title,Tags,UserName,UserRole,Timestamp,Upvotes,AcceptedAnswerID,Description\n")
    questions.forEach { q ->
        sb.append("${q.id},${escapeCsv(q.title)},${escapeCsv(q.tags)},${escapeCsv(q.userName)},${escapeCsv(q.userRole)},${q.timestamp},${q.upvotes},${q.acceptedAnswerId},${escapeCsv(q.description)}\n")
    }
    return sb.toString()
}

private fun generateQuestionsJson(questions: List<Question>): String {
    val sb = StringBuilder()
    sb.append("[\n")
    questions.forEachIndexed { i, q ->
        sb.append("  {\n")
        sb.append("    \"id\": ${q.id},\n")
        sb.append("    \"title\": \"${escapeJson(q.title)}\",\n")
        sb.append("    \"description\": \"${escapeJson(q.description)}\",\n")
        sb.append("    \"tags\": \"${escapeJson(q.tags)}\",\n")
        sb.append("    \"userName\": \"${escapeJson(q.userName)}\",\n")
        sb.append("    \"userRole\": \"${escapeJson(q.userRole)}\",\n")
        sb.append("    \"timestamp\": ${q.timestamp},\n")
        sb.append("    \"upvotes\": ${q.upvotes},\n")
        sb.append("    \"acceptedAnswerId\": ${q.acceptedAnswerId}\n")
        sb.append("  }${if (i < questions.lastIndex) "," else ""}\n")
    }
    sb.append("]")
    return sb.toString()
}

private fun generateAnswersCsv(answers: List<Answer>): String {
    val sb = StringBuilder()
    sb.append("ID,QuestionID,UserName,UserRole,Timestamp,Upvotes,IsAccepted,Content\n")
    answers.forEach { a ->
        sb.append("${a.id},${a.questionId},${escapeCsv(a.userName)},${escapeCsv(a.userRole)},${a.timestamp},${a.upvotes},${a.isAccepted},${escapeCsv(a.content)}\n")
    }
    return sb.toString()
}

private fun generateAnswersJson(answers: List<Answer>): String {
    val sb = StringBuilder()
    sb.append("[\n")
    answers.forEachIndexed { i, a ->
        sb.append("  {\n")
        sb.append("    \"id\": ${a.id},\n")
        sb.append("    \"questionId\": ${a.questionId},\n")
        sb.append("    \"userName\": \"${escapeJson(a.userName)}\",\n")
        sb.append("    \"userRole\": \"${escapeJson(a.userRole)}\",\n")
        sb.append("    \"timestamp\": ${a.timestamp},\n")
        sb.append("    \"upvotes\": ${a.upvotes},\n")
        sb.append("    \"isAccepted\": ${a.isAccepted},\n")
        sb.append("    \"content\": \"${escapeJson(a.content)}\"\n")
        sb.append("  }${if (i < answers.lastIndex) "," else ""}\n")
    }
    sb.append("]")
    return sb.toString()
}

private fun generateCommentsCsv(comments: List<Comment>): String {
    val sb = StringBuilder()
    sb.append("ID,ParentID,IsAnswerComment,UserName,Timestamp,Content\n")
    comments.forEach { c ->
        sb.append("${c.id},${c.questionOrAnswerId},${c.isAnswer},${escapeCsv(c.userName)},${c.timestamp},${escapeCsv(c.content)}\n")
    }
    return sb.toString()
}

private fun generateCommentsJson(comments: List<Comment>): String {
    val sb = StringBuilder()
    sb.append("[\n")
    comments.forEachIndexed { i, c ->
        sb.append("  {\n")
        sb.append("    \"id\": ${c.id},\n")
        sb.append("    \"parentId\": ${c.questionOrAnswerId},\n")
        sb.append("    \"isAnswerComment\": ${c.isAnswer},\n")
        sb.append("    \"userName\": \"${escapeJson(c.userName)}\",\n")
        sb.append("    \"timestamp\": ${c.timestamp},\n")
        sb.append("    \"content\": \"${escapeJson(c.content)}\"\n")
        sb.append("  }${if (i < comments.lastIndex) "," else ""}\n")
    }
    sb.append("]")
    return sb.toString()
}

private fun generateListingsCsv(listings: List<MarketplaceListing>): String {
    val sb = StringBuilder()
    sb.append("ID,Title,Price,Category,Location,Grade,Application,Brand,SellerName,Approved,Description\n")
    listings.forEach { l ->
        sb.append("${l.id},${escapeCsv(l.title)},${l.price},${escapeCsv(l.category)},${escapeCsv(l.location)},${escapeCsv(l.partsGrade)},${escapeCsv(l.application)},${escapeCsv(l.partBrand)},${escapeCsv(l.userName)},${l.isApproved},${escapeCsv(l.description)}\n")
    }
    return sb.toString()
}

private fun generateListingsJson(listings: List<MarketplaceListing>): String {
    val sb = StringBuilder()
    sb.append("[\n")
    listings.forEachIndexed { i, l ->
        sb.append("  {\n")
        sb.append("    \"id\": ${l.id},\n")
        sb.append("    \"title\": \"${escapeJson(l.title)}\",\n")
        sb.append("    \"price\": ${l.price},\n")
        sb.append("    \"category\": \"${escapeJson(l.category)}\",\n")
        sb.append("    \"location\": \"${escapeJson(l.location)}\",\n")
        sb.append("    \"partsGrade\": \"${escapeJson(l.partsGrade)}\",\n")
        sb.append("    \"application\": \"${escapeJson(l.application)}\",\n")
        sb.append("    \"partBrand\": \"${escapeJson(l.partBrand)}\",\n")
        sb.append("    \"sellerName\": \"${escapeJson(l.userName)}\",\n")
        sb.append("    \"approved\": ${l.isApproved},\n")
        sb.append("    \"description\": \"${escapeJson(l.description)}\"\n")
        sb.append("  }${if (i < listings.lastIndex) "," else ""}\n")
    }
    sb.append("]")
    return sb.toString()
}

private fun generateRatingsCsv(ratings: List<ProviderRating>): String {
    val sb = StringBuilder()
    sb.append("ID,ProviderID,RaterName,RatingValue,Timestamp,Feedback\n")
    ratings.forEach { r ->
        sb.append("${r.id},${escapeCsv(r.providerId)},${escapeCsv(r.raterName)},${r.ratingValue},${r.timestamp},${escapeCsv(r.feedback)}\n")
    }
    return sb.toString()
}

private fun generateRatingsJson(ratings: List<ProviderRating>): String {
    val sb = StringBuilder()
    sb.append("[\n")
    ratings.forEachIndexed { i, r ->
        sb.append("  {\n")
        sb.append("    \"id\": ${r.id},\n")
        sb.append("    \"providerId\": \"${escapeJson(r.providerId)}\",\n")
        sb.append("    \"raterName\": \"${escapeJson(r.raterName)}\",\n")
        sb.append("    \"ratingValue\": ${r.ratingValue},\n")
        sb.append("    \"timestamp\": ${r.timestamp},\n")
        sb.append("    \"feedback\": \"${escapeJson(r.feedback)}\"\n")
        sb.append("  }${if (i < ratings.lastIndex) "," else ""}\n")
    }
    sb.append("]")
    return sb.toString()
}

private fun generateAnalyticsJson(analytics: AdminAnalytics): String {
    val sb = StringBuilder()
    sb.append("{\n")
    sb.append("  \"visitsForum\": ${analytics.visitsForum},\n")
    sb.append("  \"visitsProCircle\": ${analytics.visitsProCircle},\n")
    sb.append("  \"visitsMarketplace\": ${analytics.visitsMarketplace},\n")
    sb.append("  \"visitsAiDiagnostics\": ${analytics.visitsAiDiagnostics},\n")
    sb.append("  \"visitsSettings\": ${analytics.visitsSettings},\n")
    sb.append("  \"whatsappClicks\": ${analytics.whatsappClicks},\n")
    sb.append("  \"aiQuestionsCount\": ${analytics.aiQuestionsCount},\n")
    sb.append("  \"upvotesGivenCount\": ${analytics.upvotesGivenCount}\n")
    sb.append("}")
    return sb.toString()
}

private fun generateMasterBackupJson(
    users: List<User>,
    questions: List<Question>,
    answers: List<Answer>,
    comments: List<Comment>,
    listings: List<MarketplaceListing>,
    ratings: List<ProviderRating>,
    analytics: AdminAnalytics
): String {
    val sb = StringBuilder()
    sb.append("{\n")
    sb.append("  \"backupTimestamp\": ${System.currentTimeMillis()},\n")
    sb.append("  \"systemVersion\": \"CocheFix-v2.1-NGN\",\n")
    sb.append("  \"users\": ${generateUsersJson(users).replace("\n", "\n  ")},\n")
    sb.append("  \"questions\": ${generateQuestionsJson(questions).replace("\n", "\n  ")},\n")
    sb.append("  \"answers\": ${generateAnswersJson(answers).replace("\n", "\n  ")},\n")
    sb.append("  \"comments\": ${generateCommentsJson(comments).replace("\n", "\n  ")},\n")
    sb.append("  \"listings\": ${generateListingsJson(listings).replace("\n", "\n  ")},\n")
    sb.append("  \"ratings\": ${generateRatingsJson(ratings).replace("\n", "\n  ")},\n")
    sb.append("  \"analytics\": ${generateAnalyticsJson(analytics).replace("\n", "\n  ")}\n")
    sb.append("}")
    return sb.toString()
}

@Composable
fun DataExportConsoleWidget(
    viewModel: MainViewModel,
    allUsers: List<User>,
    allListings: List<MarketplaceListing>,
    allQuestions: List<Question>,
    adminAnalytics: AdminAnalytics
) {
    val context = LocalContext.current
    val allAnswers by viewModel.allAnswersGlobal.collectAsStateWithLifecycle()
    val allComments by viewModel.allCommentsGlobal.collectAsStateWithLifecycle()
    val allRatings by viewModel.allRatingsGlobal.collectAsStateWithLifecycle()

    var showExportPreviewDialog by remember { mutableStateOf(false) }
    var previewTitle by remember { mutableStateOf("") }
    var previewContent by remember { mutableStateOf("") }
    var previewFormat by remember { mutableStateOf("CSV") }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Introduction & Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.3f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = "System administrator key info",
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Data Management & Export Hub",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onTertiaryContainer
                    )
                    Text(
                        text = "Extract and export core platform telemetry, community database files, user profiles, activities, and analytical metrics directly into standard CSV or JSON files.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.8f)
                    )
                }
            }
        }

        // Section 1: Membership Demographics Profiles
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Person,
                            contentDescription = "User database profiles",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Users Profile Database",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${allUsers.size} Users Registered",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Includes unique identifiers, emails, specialized roles, location, dynamic verification, and account moderation status.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            previewTitle = "User Profiles (CSV)"
                            previewContent = generateUsersCsv(allUsers)
                            previewFormat = "CSV"
                            showExportPreviewDialog = true
                        },
                        modifier = Modifier.weight(1f).testTag("export_users_csv_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Export CSV", color = Color.Black, fontSize = 12.sp)
                    }
                    Button(
                        onClick = {
                            previewTitle = "User Profiles (JSON)"
                            previewContent = generateUsersJson(allUsers)
                            previewFormat = "JSON"
                            showExportPreviewDialog = true
                        },
                        modifier = Modifier.weight(1f).testTag("export_users_json_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text("Export JSON", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // Section 2: Platform Activities & Actions Telemetry
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.List,
                        contentDescription = "Acquisition metrics section",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Platform Activities & Telemetry",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Community data, interactive diagnostics support logs, and peer validations.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Item 1: Questions
                ActivityExporterRow(
                    label = "Support Complains / Threads",
                    count = allQuestions.size,
                    onExportCsv = {
                        previewTitle = "Support Threads (CSV)"
                        previewContent = generateQuestionsCsv(allQuestions)
                        previewFormat = "CSV"
                        showExportPreviewDialog = true
                    },
                    onExportJson = {
                        previewTitle = "Support Threads (JSON)"
                        previewContent = generateQuestionsJson(allQuestions)
                        previewFormat = "JSON"
                        showExportPreviewDialog = true
                    },
                    csvTag = "export_questions_csv_btn",
                    jsonTag = "export_questions_json_btn"
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Item 2: Answers
                ActivityExporterRow(
                    label = "Solutions & Diagnoses",
                    count = allAnswers.size,
                    onExportCsv = {
                        previewTitle = "Expert Solutions (CSV)"
                        previewContent = generateAnswersCsv(allAnswers)
                        previewFormat = "CSV"
                        showExportPreviewDialog = true
                    },
                    onExportJson = {
                        previewTitle = "Expert Solutions (JSON)"
                        previewContent = generateAnswersJson(allAnswers)
                        previewFormat = "JSON"
                        showExportPreviewDialog = true
                    },
                    csvTag = "export_answers_csv_btn",
                    jsonTag = "export_answers_json_btn"
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Item 3: Comments
                ActivityExporterRow(
                    label = "Discussions & Comments",
                    count = allComments.size,
                    onExportCsv = {
                        previewTitle = "User Comments (CSV)"
                        previewContent = generateCommentsCsv(allComments)
                        previewFormat = "CSV"
                        showExportPreviewDialog = true
                    },
                    onExportJson = {
                        previewTitle = "User Comments (JSON)"
                        previewContent = generateCommentsJson(allComments)
                        previewFormat = "JSON"
                        showExportPreviewDialog = true
                    },
                    csvTag = "export_comments_csv_btn",
                    jsonTag = "export_comments_json_btn"
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Item 4: Listings
                ActivityExporterRow(
                    label = "Store Listings (Parts & Services)",
                    count = allListings.size,
                    onExportCsv = {
                        previewTitle = "Store Listings (CSV)"
                        previewContent = generateListingsCsv(allListings)
                        previewFormat = "CSV"
                        showExportPreviewDialog = true
                    },
                    onExportJson = {
                        previewTitle = "Store Listings (JSON)"
                        previewContent = generateListingsJson(allListings)
                        previewFormat = "JSON"
                        showExportPreviewDialog = true
                    },
                    csvTag = "export_listings_csv_btn",
                    jsonTag = "export_listings_json_btn"
                )

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Item 5: Ratings
                ActivityExporterRow(
                    label = "Technician Certifications / Reviews",
                    count = allRatings.size,
                    onExportCsv = {
                        previewTitle = "Expert Ratings (CSV)"
                        previewContent = generateRatingsCsv(allRatings)
                        previewFormat = "CSV"
                        showExportPreviewDialog = true
                    },
                    onExportJson = {
                        previewTitle = "Expert Ratings (JSON)"
                        previewContent = generateRatingsJson(allRatings)
                        previewFormat = "JSON"
                        showExportPreviewDialog = true
                    },
                    csvTag = "export_ratings_csv_btn",
                    jsonTag = "export_ratings_json_btn"
                )
            }
        }

        // Section 3: Telemetry Analysis Metrics
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = "Analytical Telemetry overview logo",
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Analytics & Telemetry Metrics",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Page visits, AI support interactions, upvote volumes, and direct WhatsApp redirects logs.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        previewTitle = "Analytical Dashboard Data"
                        previewContent = generateAnalyticsJson(adminAnalytics)
                        previewFormat = "JSON"
                        showExportPreviewDialog = true
                    },
                    modifier = Modifier.fillMaxWidth().testTag("export_analytics_json_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("Export Analytics Dataset (JSON)", color = Color.White)
                }
            }
        }

        // Section 4: All-Inclusive Master Admin Command Center Backup
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.DateRange,
                        contentDescription = "Master server safety backup icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "🔒 ALL-INCLUSIVE SYSTEM BACKUP",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Compiles all databases tables containing users, support threads, solutions, comments, listings, expert ratings, and website analytics into a single consolidated master JSON schema file for full backup.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        previewTitle = "Master Database Backup"
                        previewContent = generateMasterBackupJson(
                            users = allUsers,
                            questions = allQuestions,
                            answers = allAnswers,
                            comments = allComments,
                            listings = allListings,
                            ratings = allRatings,
                            analytics = adminAnalytics
                        )
                        previewFormat = "JSON"
                        showExportPreviewDialog = true
                    },
                    modifier = Modifier.fillMaxWidth().testTag("export_master_backup_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Generate Combined Master System Backup", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showExportPreviewDialog) {
        ExportPreviewDialog(
            title = previewTitle,
            content = previewContent,
            format = previewFormat,
            onDismiss = { showExportPreviewDialog = false }
        )
    }
}

@Composable
fun ActivityExporterRow(
    label: String,
    count: Int,
    onExportCsv: () -> Unit,
    onExportJson: () -> Unit,
    csvTag: String,
    jsonTag: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Box(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "$count entries",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = onExportCsv,
                modifier = Modifier.weight(1f).testTag(csvTag),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Text("CSV Data", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
            }
            OutlinedButton(
                onClick = onExportJson,
                modifier = Modifier.weight(1f).testTag(jsonTag),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Text("JSON Data", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
            }
        }
    }
}

@Composable
fun ExportPreviewDialog(
    title: String,
    content: String,
    format: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = "Validated export configuration icon",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, fontWeight = FontWeight.Black)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "A formatted export has been generated. You can analyze a scrollable preview below, copy the dataset directly to your device clipboard, or share it packaged as a raw text string with external applications.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Box(modifier = Modifier.padding(10.dp).fillMaxSize()) {
                        val scrollState = rememberScrollState()
                        Text(
                            text = content,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(scrollState)
                                .horizontalScroll(rememberScrollState())
                        )
                    }
                }
                Text(
                    text = "Total Size: ${String.format(java.util.Locale.US, "%,d", content.length)} characters",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        val clip = android.content.ClipData.newPlainText("CocheFix Export", content)
                        clipboard.setPrimaryClip(clip)
                        android.widget.Toast.makeText(context, "Copied successfully to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(1f).testTag("preview_copy_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Copy Code", color = Color.Black)
                }
                Button(
                    onClick = {
                        try {
                            val sendIntent = android.content.Intent().apply {
                                action = android.content.Intent.ACTION_SEND
                                putExtra(android.content.Intent.EXTRA_TITLE, title)
                                putExtra(android.content.Intent.EXTRA_SUBJECT, title)
                                putExtra(android.content.Intent.EXTRA_TEXT, content)
                                type = "text/plain"
                            }
                            val shareIntent = android.content.Intent.createChooser(sendIntent, "Share Backup Export:")
                            context.startActivity(shareIntent)
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Sharing failed: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.weight(1f).testTag("preview_share_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("Share Backup", color = Color.White)
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("preview_close_btn")
            ) {
                Text("Close", color = MaterialTheme.colorScheme.primary)
            }
        }
    )
}
