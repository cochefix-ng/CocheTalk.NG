package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "users")
data class User(
    @PrimaryKey val id: String, // email will serve as the unique ID / primary key
    val name: String,
    val email: String,
    val role: String, // "Car Owner", "Service Provider", "Admin"
    val verified: Boolean = false,
    val phone: String = "",
    val specialization: String = "", // e.g., "Engine", "Electrical", "Bodywork", "General"
    val businessName: String = "",
    val experience: Int = 0,
    val location: String = "",
    val isBanned: Boolean = false
) : Serializable

@Entity(tableName = "questions")
data class Question(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val userId: String,
    val userName: String,
    val userRole: String,
    val userSpecialization: String? = null,
    val userVerified: Boolean = false,
    val tags: String = "", // e.g., "Toyota, Engine"
    val timestamp: Long = System.currentTimeMillis(),
    val isPrivateEcosystem: Boolean = false, // True if restricted to mechanics only
    val upvotes: Int = 0,
    val acceptedAnswerId: Int = -1,
    val yrModel: String = "",
    val vehicleType: String = "",
    val seeConcern: Boolean = false,
    val hearConcern: Boolean = false,
    val smellConcern: Boolean = false,
    val feelConcern: Boolean = false,
    val notStarting: Boolean = false,
    val performanceConcern: Boolean = false,
    val dashboardWarningLights: Boolean = false
) : Serializable

@Entity(tableName = "answers")
data class Answer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val questionId: Int,
    val userId: String,
    val userName: String,
    val userRole: String,
    val userSpecialization: String? = null,
    val userVerified: Boolean = false,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val upvotes: Int = 0,
    val isAccepted: Boolean = false
) : Serializable

@Entity(tableName = "comments")
data class Comment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val questionOrAnswerId: Int,
    val isAnswer: Boolean, // True if commenting on an Answer, False if directly on a Question
    val userId: String,
    val userName: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "marketplace_listings")
data class MarketplaceListing(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String,
    val price: Double,
    val userId: String,
    val userName: String,
    val userRole: String,
    val userPhone: String,
    val category: String, // "Parts", "Services", "Accessories"
    val location: String,
    val imageUrl: String = "", // Resource name or empty
    val timestamp: Long = System.currentTimeMillis(),
    val isApproved: Boolean = false, // Default to false, can be approved by Admin
    val partsGrade: String = "",
    val application: String = "",
    val partBrand: String = "",
    val isFeaturedBottom: Boolean = false
) : Serializable

@Entity(tableName = "cms_configs")
data class CmsConfig(
    @PrimaryKey val id: String = "cms_singleton",
    val logoText: String = "CocheTalk.NG",
    val landingText: String = "Global vehicle aftersales platform. Ask Q&A, hire verified workshops instantly, and trade parts safely.",
    val bannerText: String = "🔥 EV workshop diagnostics certification starting next week across regional training centers! 🔥",
    val announcementText: String = "Welcome to CocheTalk.NG! All spare parts transactions are protected. Make sure to buy only from verified badge service providers.",
    val logoUrl: String = "",
    val logoIconName: String = "Build"
) : Serializable

@Entity(tableName = "admin_analytics")
data class AdminAnalytics(
    @PrimaryKey val id: String = "analytics_singleton",
    val visitsForum: Int = 142,
    val visitsProCircle: Int = 89,
    val visitsMarketplace: Int = 114,
    val visitsAiDiagnostics: Int = 203,
    val visitsSettings: Int = 45,
    val whatsappClicks: Int = 36,
    val aiQuestionsCount: Int = 27,
    val upvotesGivenCount: Int = 88
) : Serializable

@Entity(tableName = "provider_ratings")
data class ProviderRating(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val providerId: String, // service provider's user ID (email)
    val raterId: String,    // rater's user ID (email)
    val raterName: String,  // rater's name
    val ratingValue: Int,   // 1 to 5 stars
    val feedback: String,   // Review feedback text
    val timestamp: Long = System.currentTimeMillis()
) : Serializable

